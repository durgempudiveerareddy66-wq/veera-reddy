/* Captures raw PCM off the audio thread.
 *
 * MediaRecorder would give us webm/opus, which faster-whisper can only read via
 * ffmpeg, and ffmpeg may not exist on this machine. So we take Float32 frames
 * straight from the graph, downsample to 16 kHz mono here, and post Int16 to the
 * main thread. Nothing external ever decodes anything.
 */
const TARGET_RATE = 16000;

class PCMCapture extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ratio = sampleRate / TARGET_RATE;   // sampleRate is the context's rate
    this.pos = 0;
    this.running = true;
    this.port.onmessage = e => {
      if (e.data === 'stop') this.running = false;
      if (e.data === 'start') this.running = true;
    };
  }

  process(inputs) {
    if (!this.running) return true;
    const ch = inputs[0] && inputs[0][0];
    if (!ch || !ch.length) return true;

    // Linear-interpolated decimation to 16 kHz.
    const out = [];
    let p = this.pos;
    while (p < ch.length) {
      const i = Math.floor(p);
      const frac = p - i;
      const a = ch[i];
      const b = i + 1 < ch.length ? ch[i + 1] : a;
      let s = a + (b - a) * frac;
      s = Math.max(-1, Math.min(1, s));
      out.push(s < 0 ? s * 0x8000 : s * 0x7fff);
      p += this.ratio;
    }
    this.pos = p - ch.length;

    const pcm = new Int16Array(out.length);
    for (let i = 0; i < out.length; i++) pcm[i] = out[i];
    this.port.postMessage(pcm, [pcm.buffer]);
    return true;
  }
}

registerProcessor('pcm-capture', PCMCapture);
