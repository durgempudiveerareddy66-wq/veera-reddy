/* Canvas force-directed graph.
 *
 * Canvas rather than SVG on purpose: SVG needs a DOM node per element and stalls
 * somewhere past ~1,500 nodes. Repulsion uses a spatial grid with a distance
 * cutoff, so cost stays close to linear instead of O(n^2).
 *
 * Labels are drawn most-connected first and any label whose box collides with one
 * already placed is skipped — without that the hub cluster turns to mush.
 */
(function (global) {
  'use strict';

  // ---- tunables -----------------------------------------------------------
  const REPULSION      = 5200;   // strength of node-node push
  const REPULSION_CUT  = 150;    // px: beyond this, nodes ignore each other
  const SPRING         = 0.0075; // edge stiffness
  const SPRING_LEN     = 74;     // edge rest length
  const GRAVITY        = 0.0016; // pull toward centre
  const DAMPING        = 0.86;
  const ALPHA_DECAY    = 0.985;
  const ALPHA_FLOOR    = 0.012;  // never fully freezes — it keeps breathing
  const BREATH_AMP     = 0.22;
  const BREATH_SPEED   = 0.00045;
  const PULSE_EVERY_MS = 3400;   // idle: a faint pulse travels a random link
  const PULSE_MS       = 1500;
  const LABEL_MIN_DEG  = 1;      // below this, only label on hover/focus
  const MAX_LABELS     = 90;

  const TYPE_COLOUR = {
    client:  '#4fd6ff',
    project: '#7aa2f7',
    invoice: '#5ee6a8',
    person:  '#c9a6ff',
    meeting: '#8a95a3',
    idea:    '#ffb454',
    admin:   '#6b7684',
    memory:  '#5ee6a8',
  };
  const DEFAULT_COLOUR = '#55606d';
  const colourFor = t => TYPE_COLOUR[t] || DEFAULT_COLOUR;

  function Graph(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.nodes = [];
    this.edges = [];
    this.hidden = new Set();          // hidden types
    this.cam = { x: 0, y: 0, k: 1 };
    this.alpha = 1;
    this.hover = null;
    this.focus = null;
    this.pathIds = [];
    this.dragNode = null;
    this.panning = false;
    this.pulses = [];
    this.onFocus = null;
    this.onPath = null;
    this.t = 0;
    this._lastPulse = 0;
    this._bind();
    this._resize();
  }

  Graph.prototype.load = function (payload) {
    const keep = new Map(this.nodes.map(n => [n.id, n]));
    const R = Math.min(this.w, this.h) * 0.34;
    this.nodes = payload.nodes.map((n, i) => {
      const prev = keep.get(n.id);
      const a = (i / payload.nodes.length) * Math.PI * 2;
      return {
        id: n.id, title: n.title, type: n.type,
        degree: n.degree, unindexed: n.unindexed,
        x: prev ? prev.x : Math.cos(a) * R + (Math.random() - 0.5) * 40,
        y: prev ? prev.y : Math.sin(a) * R + (Math.random() - 0.5) * 40,
        vx: 0, vy: 0,
        r: 3.2 + Math.sqrt(n.degree) * 2.5,
        phase: Math.random() * Math.PI * 2,
      };
    });
    this.byId = new Map(this.nodes.map(n => [n.id, n]));
    this.index = new Map(this.nodes.map((n, i) => [i, n]));
    this.edges = payload.edges.map(([a, b]) => ({
      a: this.nodes[a], b: this.nodes[b],
    })).filter(e => e.a && e.b);
    this.adj = new Map(this.nodes.map(n => [n.id, []]));
    this.edges.forEach(e => {
      this.adj.get(e.a.id).push(e.b.id);
      this.adj.get(e.b.id).push(e.a.id);
    });
    this.alpha = 1;
  };

  // ---- visibility ---------------------------------------------------------
  Graph.prototype.visible = function (n) { return !this.hidden.has(n.type); };
  Graph.prototype.toggleType = function (t) {
    if (this.hidden.has(t)) this.hidden.delete(t); else this.hidden.add(t);
    this.alpha = Math.max(this.alpha, 0.42);
  };

  // ---- simulation ---------------------------------------------------------
  Graph.prototype.step = function () {
    const nodes = this.nodes.filter(n => this.visible(n));
    if (!nodes.length) return;
    this.t++;

    // Spatial grid: only nodes in neighbouring cells can repel each other.
    const cell = REPULSION_CUT;
    const grid = new Map();
    for (const n of nodes) {
      const key = ((n.x / cell) | 0) + ':' + ((n.y / cell) | 0);
      let bucket = grid.get(key);
      if (!bucket) grid.set(key, bucket = []);
      bucket.push(n);
    }

    const a = this.alpha;
    for (const n of nodes) {
      const cx = (n.x / cell) | 0, cy = (n.y / cell) | 0;
      for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
          const bucket = grid.get((cx + dx) + ':' + (cy + dy));
          if (!bucket) continue;
          for (const m of bucket) {
            if (m === n) continue;
            let ex = n.x - m.x, ey = n.y - m.y;
            let d2 = ex * ex + ey * ey;
            if (d2 > REPULSION_CUT * REPULSION_CUT) continue;
            if (d2 < 0.01) { ex = (Math.random() - 0.5); ey = (Math.random() - 0.5); d2 = 0.01; }
            const d = Math.sqrt(d2);
            const f = (REPULSION * a) / d2;
            n.vx += (ex / d) * f;
            n.vy += (ey / d) * f;
          }
        }
      }
    }

    for (const e of this.edges) {
      if (!this.visible(e.a) || !this.visible(e.b)) continue;
      const dx = e.b.x - e.a.x, dy = e.b.y - e.a.y;
      const d = Math.hypot(dx, dy) || 0.01;
      const f = (d - SPRING_LEN) * SPRING * a;
      const fx = (dx / d) * f, fy = (dy / d) * f;
      e.a.vx += fx; e.a.vy += fy;
      e.b.vx -= fx; e.b.vy -= fy;
    }

    for (const n of nodes) {
      n.vx -= n.x * GRAVITY * a;
      n.vy -= n.y * GRAVITY * a;
      // Breathing: a slow, tiny drift that never settles to a dead stop.
      n.vx += Math.cos(this.t * BREATH_SPEED + n.phase) * BREATH_AMP;
      n.vy += Math.sin(this.t * BREATH_SPEED * 1.3 + n.phase) * BREATH_AMP;
      if (n === this.dragNode) { n.vx = n.vy = 0; continue; }
      n.vx *= DAMPING; n.vy *= DAMPING;
      n.x += n.vx; n.y += n.vy;
    }

    this.alpha = Math.max(ALPHA_FLOOR, this.alpha * ALPHA_DECAY);
  };

  // ---- idle pulse ---------------------------------------------------------
  Graph.prototype._maybePulse = function (now) {
    if (now - this._lastPulse < PULSE_EVERY_MS || !this.edges.length) return;
    this._lastPulse = now;
    const live = this.edges.filter(e => this.visible(e.a) && this.visible(e.b));
    if (!live.length) return;
    this.pulses.push({ e: live[(Math.random() * live.length) | 0], t0: now });
  };

  // ---- drawing ------------------------------------------------------------
  Graph.prototype.toScreen = function (n) {
    return { x: (n.x - this.cam.x) * this.cam.k + this.w / 2,
             y: (n.y - this.cam.y) * this.cam.k + this.h / 2 };
  };
  Graph.prototype.toWorld = function (px, py) {
    return { x: (px - this.w / 2) / this.cam.k + this.cam.x,
             y: (py - this.h / 2) / this.cam.k + this.cam.y };
  };

  Graph.prototype.draw = function (now) {
    const ctx = this.ctx, k = this.cam.k;
    ctx.save();
    ctx.scale(this.dpr, this.dpr);
    ctx.clearRect(0, 0, this.w, this.h);

    const lit = new Set();
    const active = this.hover || this.focus;
    if (active) {
      lit.add(active.id);
      (this.adj.get(active.id) || []).forEach(id => lit.add(id));
    }
    const pathSet = new Set(this.pathIds);
    const dimming = !!active || pathSet.size > 0;

    // -- edges
    for (const e of this.edges) {
      if (!this.visible(e.a) || !this.visible(e.b)) continue;
      const onPath = pathSet.has(e.a.id) && pathSet.has(e.b.id)
        && Math.abs(this.pathIds.indexOf(e.a.id) - this.pathIds.indexOf(e.b.id)) === 1;
      const isLit = active && lit.has(e.a.id) && lit.has(e.b.id);
      let alpha = 0.15;
      if (dimming) alpha = 0.035;
      if (isLit) alpha = 0.55;
      if (onPath) alpha = 0.95;
      const A = this.toScreen(e.a), B = this.toScreen(e.b);
      ctx.beginPath();
      ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y);
      ctx.strokeStyle = onPath ? '#4fd6ff' : (isLit ? '#8fd8f0' : '#7d8b99');
      ctx.globalAlpha = alpha;
      ctx.lineWidth = onPath ? 1.8 : 1;
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // -- idle pulses
    this.pulses = this.pulses.filter(p => now - p.t0 < PULSE_MS);
    for (const p of this.pulses) {
      if (!this.visible(p.e.a) || !this.visible(p.e.b)) continue;
      const f = (now - p.t0) / PULSE_MS;
      const A = this.toScreen(p.e.a), B = this.toScreen(p.e.b);
      const x = A.x + (B.x - A.x) * f, y = A.y + (B.y - A.y) * f;
      ctx.globalAlpha = Math.sin(f * Math.PI) * 0.75;
      ctx.beginPath();
      ctx.arc(x, y, 2.1, 0, Math.PI * 2);
      ctx.fillStyle = '#4fd6ff';
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // -- nodes
    const drawn = [];
    for (const n of this.nodes) {
      if (!this.visible(n)) continue;
      const s = this.toScreen(n);
      if (s.x < -60 || s.y < -60 || s.x > this.w + 60 || s.y > this.h + 60) continue;
      const isActive = active === n;
      const onPath = pathSet.has(n.id);
      let alpha = 1;
      if (dimming && !lit.has(n.id) && !onPath) alpha = 0.1;   // everything else drops
      const lift = isActive ? 2.4 : 0;                          // hover lifts it
      const r = Math.max(1.6, (n.r + lift) * Math.sqrt(k));

      ctx.globalAlpha = alpha;
      if (isActive || onPath) {
        ctx.beginPath();
        ctx.arc(s.x, s.y, r * 2.7, 0, Math.PI * 2);
        ctx.fillStyle = colourFor(n.type);
        ctx.globalAlpha = alpha * 0.14;
        ctx.fill();
        ctx.globalAlpha = alpha;
      }
      ctx.beginPath();
      ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
      ctx.fillStyle = n.unindexed ? '#3b434d' : colourFor(n.type);
      ctx.fill();
      if (n.unindexed) {
        ctx.strokeStyle = '#6b7684'; ctx.lineWidth = 1;
        ctx.setLineDash([2, 2]); ctx.stroke(); ctx.setLineDash([]);
      }
      if (isActive) {
        ctx.strokeStyle = '#e7ecf2'; ctx.lineWidth = 1.4; ctx.stroke();
      }
      drawn.push({ n, s, r, alpha, isActive, onPath });
    }
    ctx.globalAlpha = 1;

    // -- labels: most-connected first, skip any box that collides
    drawn.sort((a, b) => b.n.degree - a.n.degree);
    ctx.font = '11px ui-sans-serif, system-ui, sans-serif';
    ctx.textBaseline = 'middle';
    const boxes = [];
    let placed = 0;
    for (const d of drawn) {
      const must = d.isActive || d.onPath;
      if (!must) {
        if (placed >= MAX_LABELS) continue;
        if (d.n.degree < LABEL_MIN_DEG) continue;
        if (dimming && d.alpha <= 0.1) continue;
        if (k < 0.42) continue;
      }
      const text = d.n.title.length > 26 ? d.n.title.slice(0, 25) + '…' : d.n.title;
      const w = ctx.measureText(text).width;
      const x = d.s.x + d.r + 6, y = d.s.y;
      const box = { x0: x - 2, y0: y - 7, x1: x + w + 2, y1: y + 7 };
      // Don't draw labels under the floating panels — they read as garbage there.
      if (!must && (box.x0 < this.gutter.left || box.x1 > this.w - this.gutter.right ||
                    box.y1 > this.h - this.gutter.bottom)) continue;
      const clash = boxes.some(b => !(box.x1 < b.x0 || box.x0 > b.x1 ||
                                      box.y1 < b.y0 || box.y0 > b.y1));
      if (clash && !must) continue;
      boxes.push(box);
      placed++;
      ctx.globalAlpha = must ? 1 : Math.min(d.alpha, 0.82);
      ctx.fillStyle = must ? '#e7ecf2' : '#9aa5b1';
      ctx.fillText(text, x, y);
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  };

  Graph.prototype.frame = function (now) {
    this._maybePulse(now);
    this.step();
    this.draw(now);
  };

  // ---- interaction --------------------------------------------------------
  Graph.prototype.at = function (px, py) {
    let best = null, bestD = 18;
    for (const n of this.nodes) {
      if (!this.visible(n)) continue;
      const s = this.toScreen(n);
      const d = Math.hypot(s.x - px, s.y - py);
      if (d < Math.max(bestD, n.r * this.cam.k + 6)) { best = n; bestD = d; }
    }
    return best;
  };

  Graph.prototype._bind = function () {
    const c = this.canvas;
    let last = null, moved = false;

    c.addEventListener('mousedown', ev => {
      const hit = this.at(ev.offsetX, ev.offsetY);
      moved = false;
      last = { x: ev.clientX, y: ev.clientY };
      if (hit) { this.dragNode = hit; }
      else { this.panning = true; c.classList.add('grabbing'); }
    });

    window.addEventListener('mousemove', ev => {
      const rect = c.getBoundingClientRect();
      const px = ev.clientX - rect.left, py = ev.clientY - rect.top;
      if (this.dragNode && last) {
        moved = true;
        const w = this.toWorld(px, py);
        this.dragNode.x = w.x; this.dragNode.y = w.y;
        this.alpha = Math.max(this.alpha, 0.3);
        return;
      }
      if (this.panning && last) {
        moved = true;
        this.cam.x -= (ev.clientX - last.x) / this.cam.k;
        this.cam.y -= (ev.clientY - last.y) / this.cam.k;
        last = { x: ev.clientX, y: ev.clientY };
        return;
      }
      if (px < 0 || py < 0 || px > this.w || py > this.h) { this.hover = null; return; }
      this.hover = this.at(px, py);
      c.style.cursor = this.hover ? 'pointer' : (this.panning ? 'grabbing' : 'grab');
    });

    window.addEventListener('mouseup', ev => {
      if (this.dragNode && !moved) {
        const hit = this.dragNode;
        if (ev.shiftKey && this.focus && this.focus !== hit) {
          if (this.onPath) this.onPath(this.focus.id, hit.id);
        } else {
          this.pathIds = [];
          this.focus = hit;
          if (this.onFocus) this.onFocus(hit.id);
        }
      } else if (this.panning && !moved) {
        this.focus = null; this.pathIds = [];
        if (this.onFocus) this.onFocus(null);
      }
      this.dragNode = null; this.panning = false; last = null;
      c.classList.remove('grabbing');
    });

    c.addEventListener('wheel', ev => {
      ev.preventDefault();
      const before = this.toWorld(ev.offsetX, ev.offsetY);
      const k = Math.min(4, Math.max(0.22, this.cam.k * (ev.deltaY < 0 ? 1.12 : 0.893)));
      this.cam.k = k;
      const after = this.toWorld(ev.offsetX, ev.offsetY);
      this.cam.x += before.x - after.x;
      this.cam.y += before.y - after.y;
    }, { passive: false });

    window.addEventListener('resize', () => this._resize());
  };

  Graph.prototype._resize = function () {
    this.dpr = window.devicePixelRatio || 1;
    this.w = window.innerWidth;
    this.h = window.innerHeight;
    const wide = this.w > 1180;                 // panels hide below this
    this.gutter = { left: wide ? 348 : 8, right: wide ? 288 : 8, bottom: 132 };
    this.canvas.width = this.w * this.dpr;
    this.canvas.height = this.h * this.dpr;
    this.canvas.style.width = this.w + 'px';
    this.canvas.style.height = this.h + 'px';
  };

  Graph.prototype.focusById = function (id) {
    const n = this.byId && this.byId.get(id);
    if (!n) return;
    this.focus = n; this.pathIds = [];
    this.cam.x = n.x; this.cam.y = n.y;
    this.alpha = Math.max(this.alpha, 0.25);
  };

  global.Graph = Graph;
  global.graphColourFor = colourFor;
})(window);
