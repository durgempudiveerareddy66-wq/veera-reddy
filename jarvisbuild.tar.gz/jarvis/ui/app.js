/* JARVIS front end.
 *
 * Two things here are deliberate and easy to get wrong:
 *  - the audio level loop runs on setInterval, never requestAnimationFrame. RAF
 *    stops dead in a backgrounded tab and the mic goes silently deaf.
 *  - the mic is muted while JARVIS speaks. Without that it transcribes itself
 *    through the speakers and talks to itself forever.
 */
(function () {
  'use strict';

  // ---- turn-taking, tune these -------------------------------------------
  const SILENCE_MS        = 900;    // end the turn after this long below threshold
  const SILENCE_THRESHOLD = 0.014;  // RMS level counted as silence
  const LEVEL_INTERVAL_MS = 50;     // setInterval, not RAF, on purpose
  const MIN_SPEECH_MS     = 350;    // ignore blips shorter than this
  const MAX_TURN_MS       = 30000;  // hard stop so a stuck mic cannot run forever
  const HEALTH_POLL_MS    = 15000;

  const EXAMPLES = [
    'Ask me anything',
    'What am I owed?',
    'Who is Ines Okafor?',
    'Brief me',
    'Plan my day',
    'Which client is worth the most?',
    'What slipped this week?',
    'Remember that Fenwick pays late',
  ];

  const $ = s => document.querySelector(s);
  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };

  const state = {
    health: null,
    muted: false,
    reactor: 'idle',
    listening: false,
    speaking: false,
    level: 0,
    audio: null,
    lastFocus: null,
  };

  // ======================================================== graph + panels
  const graph = new Graph($('#graph'));
  let running = true;
  (function loop(now) {
    if (running) graph.frame(now || performance.now());
    requestAnimationFrame(loop);
  })();

  graph.onFocus = id => {
    state.lastFocus = id;
    if (!id) { renderInspector(null); return; }
    fetch('/api/note?id=' + encodeURIComponent(id))
      .then(r => r.json()).then(renderInspector)
      .catch(() => renderInspector(null));
  };

  graph.onPath = (a, b) => {
    fetch('/api/path?a=' + encodeURIComponent(a) + '&b=' + encodeURIComponent(b))
      .then(r => r.json())
      .then(d => {
        graph.pathIds = d.path || [];
        if (!graph.pathIds.length) {
          caption('No path between those two.');
        } else {
          caption(graph.pathIds.length - 1 + ' hop' +
                  (graph.pathIds.length === 2 ? '' : 's') + ' between them');
        }
      });
  };

  function loadGraph() {
    return fetch('/api/graph').then(r => r.json()).then(d => {
      graph.load(d);
      renderFilters(d.counts);
      renderHubs(d.nodes);
    });
  }

  function renderFilters(counts) {
    const box = $('#filters');
    box.innerHTML = '';
    Object.keys(counts).sort().forEach(type => {
      const b = el('button', 'filter' + (graph.hidden.has(type) ? ' off' : ''));
      const sw = el('span', 'sw'); sw.style.background = graphColourFor(type);
      b.appendChild(sw);
      b.appendChild(el('span', null, type));
      b.appendChild(el('span', 'count', counts[type]));
      b.onclick = () => { graph.toggleType(type); renderFilters(counts); };
      box.appendChild(b);
    });
  }

  function renderHubs(nodes) {
    const box = $('#hubList');
    box.innerHTML = '';
    nodes.slice().sort((a, b) => b.degree - a.degree || a.title.localeCompare(b.title))
      .slice(0, 10).forEach(n => {
        const b = el('button', 'hub');
        b.appendChild(el('span', 'n', n.degree));
        const sw = el('span', 'sw'); sw.style.background = graphColourFor(n.type);
        b.appendChild(sw);
        b.appendChild(el('span', null, n.title));
        b.onclick = () => { graph.focusById(n.id); graph.onFocus(n.id); };
        box.appendChild(b);
      });
  }

  function renderInspector(note) {
    const box = $('#inspectorBody');
    box.innerHTML = '';
    if (!note || note.error) {
      box.appendChild(el('p', 'empty',
        'Click a node to open it. Shift-click a second to trace the shortest path.'));
      return;
    }
    box.appendChild(el('h3', 'note-title', note.title));
    box.appendChild(el('div', 'note-meta',
      `${note.type} · ${note.degree} link${note.degree === 1 ? '' : 's'} · ${note.file}`));
    if (note.unindexed) {
      const w = el('div', 'flag', 'Unindexed — ' + note.unindexed +
        '. Its text is not in the graph, so I will not quote from it.');
      box.appendChild(w);
    }
    if (note.injection && note.injection.length) {
      box.appendChild(el('div', 'flag',
        'This file contains text addressed to me rather than to you. It is treated as ' +
        'data and never obeyed. Patterns matched: ' + note.injection.length + '.'));
    }
    // The H1 is already the panel heading — don't print it twice.
    const body = (note.text || '').replace(/^\s*#\s+.*\n+/, '').trim();
    box.appendChild(el('div', 'note-text', body.slice(0, 4000)));
    if (note.links && note.links.length) {
      const wrap = el('div', 'note-links');
      note.links.forEach(l => wrap.appendChild(el('span', 'chip', l)));
      box.appendChild(wrap);
    }
  }

  // ======================================================== health + banners
  function banner(cls, text, id) {
    const b = el('div', 'badge ' + cls);
    b.appendChild(el('span', 'dot'));
    b.appendChild(el('span', null, text));
    if (id) b.id = id;
    return b;
  }

  function renderHealth(h) {
    state.health = h;
    const box = $('#banners');
    box.innerHTML = '';

    if (!h.model.configured) {
      box.appendChild(banner('bad', 'model offline — keyword routing'));
    } else if (h.model.last_error) {
      box.appendChild(banner('bad', 'model error — ' +
        String(h.model.last_error).slice(0, 70)));
    } else if (h.model.mode === 'json') {
      box.appendChild(banner('warn',
        'model has no tools support — strict-JSON mode · ' + h.model.model));
    }

    if (!h.stt.ok || !h.tts.ok) {
      box.appendChild(banner('warn', 'voice offline: run ./setup_voice.sh'));
    } else if (h.stt.first_run) {
      box.appendChild(banner('warn', 'preparing voice — first use downloads ~75 MB'));
    }

    if (h.data.demo) {
      box.appendChild(banner('good', 'demo data — invented fixtures'));
    }
    (h.data.problems || []).forEach(p => box.appendChild(banner('warn', p)));
    if (h.index.injection_flagged) {
      box.appendChild(banner('warn', h.index.injection_flagged +
        ' file(s) contain text aimed at me — flagged, never obeyed'));
    }
    if (h.model.configured) {
      box.appendChild(banner('good',
        `${h.model.model} · ${h.model.requests} request${h.model.requests === 1 ? '' : 's'}`));
    }
  }

  function pollHealth() {
    fetch('/api/health').then(r => r.json()).then(renderHealth).catch(() => {});
  }

  // ======================================================== reactor
  const rc = $('#reactorCanvas');
  const rctx = rc.getContext('2d');
  const COLOURS = { idle: '#5b6570', listening: '#4fd6ff',
                    thinking: '#ffb454', speaking: '#5ee6a8' };

  function setReactor(s) {
    state.reactor = s;
    $('#reactorState').textContent = s;
    $('#bars').classList.toggle('live', s === 'listening');
  }

  (function drawReactor() {
    const t = performance.now();
    const c = COLOURS[state.reactor] || COLOURS.idle;
    const S = rc.width, C = S / 2;
    rctx.clearRect(0, 0, S, S);

    const pulse = state.reactor === 'idle' ? 0.5 + Math.sin(t / 1400) * 0.08
      : state.reactor === 'thinking' ? 0.62 + Math.sin(t / 260) * 0.16
      : state.reactor === 'listening' ? 0.55 + state.level * 2.4
      : 0.66 + Math.sin(t / 420) * 0.14;

    // one soft glow, reserved for the reactor alone
    const g = rctx.createRadialGradient(C, C, 6, C, C, S * 0.46);
    g.addColorStop(0, c + '44');
    g.addColorStop(1, 'transparent');
    rctx.fillStyle = g;
    rctx.beginPath(); rctx.arc(C, C, S * 0.46, 0, Math.PI * 2); rctx.fill();

    rctx.strokeStyle = 'rgba(255,255,255,0.08)';
    rctx.lineWidth = 1;
    [0.30, 0.40].forEach(r => {
      rctx.beginPath(); rctx.arc(C, C, S * r, 0, Math.PI * 2); rctx.stroke();
    });

    rctx.strokeStyle = c;
    rctx.lineWidth = 2.2;
    rctx.beginPath();
    rctx.arc(C, C, S * 0.35, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(pulse, 1));
    rctx.stroke();

    const spin = t / (state.reactor === 'thinking' ? 420 : 2600);
    for (let i = 0; i < 3; i++) {
      const a = spin + (i * Math.PI * 2) / 3;
      rctx.beginPath();
      rctx.arc(C + Math.cos(a) * S * 0.35, C + Math.sin(a) * S * 0.35, 2.6, 0, Math.PI * 2);
      rctx.fillStyle = c; rctx.fill();
    }

    rctx.beginPath();
    rctx.arc(C, C, S * 0.11 * (0.9 + pulse * 0.22), 0, Math.PI * 2);
    rctx.fillStyle = c; rctx.globalAlpha = 0.85; rctx.fill(); rctx.globalAlpha = 1;
    requestAnimationFrame(drawReactor);
  })();

  const BAR_COUNT = 13;
  (function buildBars() {
    const box = $('#bars');
    for (let i = 0; i < BAR_COUNT; i++) box.appendChild(el('i'));
  })();

  function paintBars(level) {
    const bars = $('#bars').children;
    for (let i = 0; i < bars.length; i++) {
      const d = Math.abs(i - (BAR_COUNT - 1) / 2) / ((BAR_COUNT - 1) / 2);
      const h = 3 + level * 60 * (1 - d * 0.7) * (0.65 + Math.random() * 0.7);
      bars[i].style.height = Math.min(22, Math.max(3, h)) + 'px';
    }
  }

  // ======================================================== answers
  function caption(text, sticky) {
    const c = $('#caption');
    c.textContent = text || '';
    c.classList.toggle('show', !!text);
    if (text && !sticky) {
      clearTimeout(caption._t);
      caption._t = setTimeout(() => c.classList.remove('show'), 3500);
    }
  }

  function row(k, v) {
    const r = el('div', 'row');
    r.appendChild(el('div', 'k', k));
    const val = el('div', 'v');
    if (v instanceof Node) val.appendChild(v); else val.textContent = v;
    r.appendChild(val);
    return r;
  }

  function renderCard(card) {
    const c = el('div', 'card');
    c.appendChild(el('div', 'kind', card.kind));

    if (card.kind === 'search') {
      if (!card.hits.length) {
        c.appendChild(el('div', 'empty', 'No file matches “' + card.query + '”.'));
      }
      card.hits.forEach(h => {
        const wrap = el('div');
        const f = el('div', 'file', h.file + '  ·  ' + h.type);
        f.onclick = () => { graph.focusById(h.id); graph.onFocus(h.id); };
        wrap.appendChild(f);
        wrap.appendChild(el('div', 'snippet', h.excerpt));
        c.appendChild(row(h.title, wrap));
      });
      if (card.flagged && card.flagged.length) {
        c.appendChild(el('div', 'flag',
          'Flagged, not obeyed: ' + card.flagged.join(', ') +
          ' contains instructions aimed at me.'));
      }
    } else if (card.kind === 'web') {
      c.appendChild(row('source', card.source));
      card.results.forEach(r => {
        const a = el('a', null, r.title);
        a.href = r.url; a.target = '_blank'; a.rel = 'noopener noreferrer';
        const wrap = el('div');
        wrap.appendChild(a);
        wrap.appendChild(el('div', 'snippet', r.snippet));
        c.appendChild(row('', wrap));
      });
      if (card.error) c.appendChild(el('div', 'flag', card.error));
    } else if (card.kind === 'inbox') {
      c.appendChild(row('unread', card.unread + ' of ' + card.messages.length));
      c.appendChild(row('known senders', card.known + ' already in your files'));
      card.messages.forEach(m => {
        const wrap = el('div');
        wrap.appendChild(el('div', null, m.subject + (m.unread ? '  •' : '')));
        wrap.appendChild(el('div', 'snippet',
          m.known ? 'known — ' + m.known_as : 'not in your files'));
        c.appendChild(row(m.from, wrap));
      });
      if (card.source && !card.source.live) {
        c.appendChild(el('div', 'flag', 'Source: ' + card.source.detail));
      }
      if (card.flagged && card.flagged.length) {
        c.appendChild(el('div', 'flag',
          'Flagged, not obeyed: message from ' + card.flagged.join(', ')));
      }
    } else if (card.kind === 'brief') {
      c.appendChild(row('date', card.date));
      card.events.forEach(e => c.appendChild(row(String(e.start).slice(11, 16), e.title)));
      if (!card.events.length) c.appendChild(row('diary', 'nothing today'));
      card.unread.forEach(u => c.appendChild(row('unread', u.from + ' — ' + u.subject)));
      card.slipped.forEach(s => c.appendChild(row('slipped', s.title + ' (due ' + s.due + ')')));
      (card.sources || []).filter(s => !s.live).forEach(s =>
        c.appendChild(el('div', 'flag', s.name + ': ' + s.detail)));
    } else if (card.kind === 'plan') {
      c.appendChild(row('window', card.window + (card.placeholder_hours ? '  (placeholder)' : '')));
      card.items.forEach(i => {
        const wrap = el('div');
        wrap.appendChild(el('div', null, i.title));
        wrap.appendChild(el('div', 'snippet',
          i.why + (i.overdue ? ' · overdue' : '') + (i.due ? ' · due ' + i.due : '')));
        c.appendChild(row(String(i.n), wrap));
      });
      if (card.caveat) c.appendChild(el('div', 'flag', card.caveat));
    } else if (card.kind === 'memory') {
      if (card.ok) {
        c.appendChild(row('written to', card.file));
        c.appendChild(row('fact', card.fact));
      } else {
        c.appendChild(el('div', 'flag', card.error));
      }
    } else {
      c.appendChild(el('div', 'snippet', JSON.stringify(card).slice(0, 400)));
    }
    return c;
  }

  function renderAnswer(a) {
    const box = $('#answer');
    box.innerHTML = '';
    box.classList.add('show');
    box.appendChild(el('div', 'spoken', a.spoken));
    (a.cards || []).forEach(card => box.appendChild(renderCard(card)));
    if (a.mode === 'keyword') {
      box.appendChild(el('div', 'flag',
        'Answered by keyword routing, not the model' + (a.error ? ' — ' + a.error : '') + '.'));
    }
    if (a.injection_report) {
      box.appendChild(el('div', 'flag',
        'Reported, not obeyed: ' + a.injection_report.join(', ')));
    }
    box.scrollTop = 0;
    if (a.health) renderHealth(a.health);
  }

  // ======================================================== asking
  let asking = false;
  function ask(question) {
    if (!question || asking) return Promise.resolve();
    asking = true;
    setReactor('thinking');
    $('#ask').value = '';
    return fetch('/api/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question }),
    }).then(r => r.json()).then(a => {
      renderAnswer(a);
      asking = false;
      if (!state.muted) return speak(a.spoken);
      setReactor(state.listening ? 'listening' : 'idle');
    }).catch(err => {
      asking = false;
      setReactor('idle');
      renderAnswer({ spoken: 'The server did not answer: ' + err.message, cards: [] });
    });
  }

  // ======================================================== speaking
  let audioEl = null;
  function speak(text) {
    if (!text || state.muted) { setReactor('idle'); return Promise.resolve(); }
    if (state.health && !state.health.tts.ok) { setReactor('idle'); return Promise.resolve(); }
    setReactor('speaking');
    state.speaking = true;                 // the mic goes deaf while this is true
    return fetch('/api/speak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    }).then(r => {
      if (!r.ok) throw new Error('tts ' + r.status);
      return r.blob();
    }).then(blob => new Promise(resolve => {
      stopSpeaking();
      audioEl = new Audio(URL.createObjectURL(blob));
      audioEl.onended = audioEl.onerror = () => { finishSpeaking(); resolve(); };
      audioEl.play().catch(() => { finishSpeaking(); resolve(); });
    })).catch(() => { finishSpeaking(); });
  }

  function stopSpeaking() {
    if (audioEl) { try { audioEl.pause(); } catch (e) {} audioEl = null; }
  }

  function finishSpeaking() {
    stopSpeaking();
    state.speaking = false;
    setReactor(state.listening ? 'listening' : 'idle');
  }

  // ======================================================== listening
  const mic = {
    ctx: null, stream: null, node: null, analyser: null, source: null,
    chunks: [], timer: null, quietSince: 0, startedAt: 0, mode: null,
    recorder: null,
  };

  async function startListening() {
    if (state.listening) return;
    if (state.health && !state.health.stt.ok) {
      caption('voice offline: run ./setup_voice.sh', true);
      return;
    }
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: true,
                 noiseSuppression: true, autoGainControl: true },
      });
    } catch (err) {
      // A blocked mic that produces no error is the worst failure in this build,
      // so say it loudly rather than sitting there looking alive.
      caption('microphone blocked or unavailable — ' + err.name, true);
      $('#micBtn').classList.remove('rec');
      setReactor('idle');
      return;
    }

    mic.stream = stream;
    mic.ctx = new (window.AudioContext || window.webkitAudioContext)();
    mic.source = mic.ctx.createMediaStreamSource(stream);
    mic.analyser = mic.ctx.createAnalyser();
    mic.analyser.fftSize = 1024;
    mic.source.connect(mic.analyser);
    mic.chunks = [];
    mic.startedAt = performance.now();
    mic.quietSince = 0;

    let worklet = false;
    if (mic.ctx.audioWorklet) {
      try {
        await mic.ctx.audioWorklet.addModule('/pcm-worklet.js');
        mic.node = new AudioWorkletNode(mic.ctx, 'pcm-capture');
        mic.node.port.onmessage = ev => {
          if (state.speaking) return;             // deaf while we talk
          mic.chunks.push(new Int16Array(ev.data));
        };
        mic.source.connect(mic.node);
        mic.node.connect(mic.ctx.destination);    // required in some browsers
        worklet = true;
        mic.mode = 'worklet';
      } catch (err) {
        worklet = false;
      }
    }

    if (!worklet) {
      mic.mode = 'mediarecorder';
      caption('AudioWorklet unavailable — using MediaRecorder, which needs ffmpeg ' +
              'installed for transcription', true);
      try {
        mic.recorder = new MediaRecorder(stream);
        mic.recorder.ondataavailable = e => mic.chunks.push(e.data);
        mic.recorder.start();
      } catch (err) {
        caption('no usable audio capture in this browser — ' + err.name, true);
        stopListening(false);
        return;
      }
    }

    state.listening = true;
    $('#micBtn').classList.add('rec');
    setReactor('listening');
    caption('listening…', true);

    // setInterval, NOT requestAnimationFrame: RAF halts in a background tab.
    const buf = new Uint8Array(mic.analyser.fftSize);
    mic.timer = setInterval(() => {
      mic.analyser.getByteTimeDomainData(buf);
      let sum = 0;
      for (let i = 0; i < buf.length; i++) {
        const v = (buf[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / buf.length);
      state.level = state.speaking ? 0 : rms;
      paintBars(state.level);

      if (state.speaking) { mic.quietSince = 0; return; }
      const now = performance.now();
      if (rms < SILENCE_THRESHOLD) {
        if (!mic.quietSince) mic.quietSince = now;
        const spoke = now - mic.startedAt > MIN_SPEECH_MS;
        if (spoke && now - mic.quietSince > SILENCE_MS && hasAudio()) endTurn();
      } else {
        mic.quietSince = 0;
      }
      if (now - mic.startedAt > MAX_TURN_MS && hasAudio()) endTurn();
    }, LEVEL_INTERVAL_MS);
  }

  function hasAudio() {
    if (mic.mode === 'worklet') {
      return mic.chunks.reduce((n, c) => n + c.length, 0) > 16000 * 0.4;
    }
    return mic.chunks.length > 0;
  }

  function stopListening(keep) {
    if (mic.timer) { clearInterval(mic.timer); mic.timer = null; }
    if (mic.node) { try { mic.node.disconnect(); } catch (e) {} mic.node = null; }
    if (mic.recorder && mic.recorder.state === 'recording') {
      try { mic.recorder.stop(); } catch (e) {}
    }
    if (mic.stream) mic.stream.getTracks().forEach(t => t.stop());
    if (mic.ctx) { try { mic.ctx.close(); } catch (e) {} mic.ctx = null; }
    mic.stream = null;
    state.listening = false;
    state.level = 0;
    paintBars(0);
    $('#micBtn').classList.remove('rec');
    if (!keep) { caption(''); setReactor(state.speaking ? 'speaking' : 'idle'); }
  }

  function endTurn() {
    const chunks = mic.chunks.slice();
    const mode = mic.mode;
    stopListening(true);
    caption('transcribing…', true);
    setReactor('thinking');

    let body, headers;
    if (mode === 'worklet') {
      const total = chunks.reduce((n, c) => n + c.length, 0);
      const merged = new Int16Array(total);
      let o = 0;
      chunks.forEach(c => { merged.set(c, o); o += c.length; });
      body = merged.buffer;
      headers = { 'Content-Type': 'application/octet-stream',
                  'X-Audio-Format': 'pcm16', 'X-Audio-Rate': '16000' };
    } else {
      body = new Blob(chunks);
      headers = { 'Content-Type': 'application/octet-stream' };
    }

    fetch('/api/listen', { method: 'POST', headers, body })
      .then(r => r.json())
      .then(d => {
        if (d.error) { caption(d.banner || d.error, true); setReactor('idle'); return; }
        const text = (d.text || '').trim();
        if (!text) { caption('did not catch that', false); setReactor('idle'); return; }
        caption(text, false);
        return ask(text);
      })
      .catch(err => { caption('transcription failed — ' + err.message, true);
                      setReactor('idle'); });
  }

  function bargeIn() {
    // Barge-in is always explicit: the mic button, Space, or Esc.
    if (state.speaking) { finishSpeaking(); caption('stopped'); return true; }
    return false;
  }

  // ======================================================== wiring
  $('#micBtn').onclick = () => {
    if (bargeIn()) return;
    if (state.listening) stopListening(false); else startListening();
  };

  $('#muteBtn').onclick = () => {
    state.muted = !state.muted;
    $('#muteBtn').classList.toggle('on', state.muted);
    $('#muteBtn').textContent = state.muted ? '✕' : '♪';
    if (state.muted) finishSpeaking();
    caption(state.muted ? 'speech muted' : 'speech on');
  };

  $('#briefBtn').onclick = () => ask('Brief me');
  $('#planBtn').onclick = () => ask('Plan my day');
  $('#memBtn').onclick = () => {
    fetch('/api/memory').then(r => r.json()).then(d => {
      renderAnswer({
        spoken: d.facts.length
          ? `${d.facts.length} fact${d.facts.length === 1 ? '' : 's'} in memory. Nothing is written there unless you ask.`
          : 'Memory is empty. I only write there when you ask me to.',
        cards: d.facts.length
          ? [{ kind: 'memory', ok: true, file: 'memory/',
               fact: d.facts.map(f => f.fact).join(' · ') }]
          : [],
      });
    });
  };

  $('#ask').addEventListener('keydown', ev => {
    if (ev.key === 'Enter') { ev.preventDefault(); ask($('#ask').value.trim()); }
  });

  window.addEventListener('keydown', ev => {
    if (ev.key === 'Escape') {
      if (!bargeIn() && state.listening) stopListening(false);
      return;
    }
    if (ev.code === 'Space' && document.activeElement !== $('#ask')) {
      ev.preventDefault();
      if (bargeIn()) return;
      if (state.listening) stopListening(false); else startListening();
    }
  });

  // rotating example prompt
  let exIdx = 0;
  setInterval(() => {
    if (document.activeElement === $('#ask') || $('#ask').value) return;
    exIdx = (exIdx + 1) % EXAMPLES.length;
    $('#ask').placeholder = EXAMPLES[exIdx];
  }, 4200);

  // ======================================================== go
  loadGraph();
  pollHealth();
  setInterval(pollHealth, HEALTH_POLL_MS);
  setReactor('idle');
  paintBars(0);
})();
