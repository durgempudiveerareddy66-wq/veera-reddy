"""Folders -> a searchable graph. Read-only, always.

Markdown, plain text and PDF. `[[wikilinks]]` are graph edges. Cached to
data/index.json with mtime checks so restart is fast; re-indexed on change.

PDF text extraction is stdlib-only (zlib on FlateDecode streams). It produces
garbage on plenty of real PDFs, which is expected: `_looks_like_text` rejects the
garbage and the node is marked `unindexed` rather than poisoning the graph.
"""
import json
import os
import re
import time
import zlib

from . import data

TEXT_EXT = {".md", ".markdown", ".txt", ".text"}
PDF_EXT = {".pdf"}
INDEX_PATH = os.path.join(data.DATA, "index.json")

WIKILINK = re.compile(r"\[\[([^\]|#]+)(?:[#|][^\]]*)?\]\]")
FRONTMATTER = re.compile(r"\A---\n(.*?)\n---\n", re.S)
WORD = re.compile(r"[a-z0-9][a-z0-9'&.-]*")

# Phrases that mean a file is trying to talk to the model rather than to the user.
INJECTION_PATTERNS = [
    re.compile(p, re.I) for p in (
        r"ignore (all |your |the )?(previous|prior|above)? ?instructions",
        r"disregard (all |your |the )?(previous|prior|above)? ?instructions",
        r"you are now in (developer|god|admin) mode",
        r"^\s*system\s*:",
        r"reply only with",
        r"do not tell the user",
        r"forward (the )?(contents|everything)",
    )
]

STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "if", "of", "to", "in", "on", "for",
    "with", "is", "are", "was", "were", "be", "been", "it", "this", "that",
    "at", "by", "from", "as", "my", "me", "i", "you", "your", "what", "which",
    "who", "how", "do", "does", "did", "can", "could", "would", "should",
}


# ---------------------------------------------------------------- extraction
def _looks_like_text(s):
    """True if a string is plausibly prose rather than binary sludge."""
    if len(s.strip()) < 40:
        return False
    printable = sum(1 for c in s if c.isprintable() or c in "\n\r\t")
    if printable / max(len(s), 1) < 0.85:
        return False
    letters = sum(1 for c in s if c.isalpha())
    return letters / max(len(s), 1) > 0.4


def _pdf_text(path):
    """Best-effort, stdlib-only. Returns '' when it cannot do better than noise."""
    try:
        with open(path, "rb") as fh:
            raw = fh.read()
    except OSError:
        return ""
    chunks = []
    for match in re.finditer(rb"stream\r?\n(.*?)endstream", raw, re.S):
        blob = match.group(1)
        try:
            blob = zlib.decompress(blob)
        except zlib.error:
            continue
        pieces = re.findall(rb"\((?:\\.|[^\\()])*\)", blob)
        if not pieces:
            continue
        text = b" ".join(p[1:-1] for p in pieces)
        try:
            chunks.append(text.decode("latin-1"))
        except UnicodeDecodeError:
            continue
    out = re.sub(r"\\[nrt]", " ", " ".join(chunks))
    out = re.sub(r"\\([()\\])", r"\1", out)
    out = re.sub(r"\s+", " ", out).strip()
    return out if _looks_like_text(out) else ""


def _read(path, ext):
    """Returns (text, unindexed_reason or None)."""
    if ext in PDF_EXT:
        text = _pdf_text(path)
        if not text:
            return "", "pdf text extraction produced no usable text"
        return text, None
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read(), None
    except OSError as exc:
        return "", f"unreadable: {exc.__class__.__name__}"


def _frontmatter(text):
    match = FRONTMATTER.match(text)
    if not match:
        return {}
    out = {}
    for line in match.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            out[k.strip().lower()] = v.strip()
    return out


def _title(text, path):
    for line in text.splitlines():
        if line.startswith("# "):
            return line[2:].strip()
    return os.path.splitext(os.path.basename(path))[0]


def tokens(text):
    return [w for w in WORD.findall(text.lower()) if w not in STOPWORDS and len(w) > 1]


def scan_injection(text):
    return [p.pattern for p in INJECTION_PATTERNS if p.search(text)]


# ---------------------------------------------------------------- the index
class Index:
    def __init__(self):
        self.notes = {}          # id -> note dict
        self.edges = []          # (src_id, dst_id)
        self.roots = []
        self.problems = []
        self.built_at = 0
        self._adj = {}
        self._by_title = {}

    # -- building ---------------------------------------------------------
    def _walk(self, root, excludes):
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames
                           if not any(x in os.path.join(dirpath, d) for x in excludes)]
            for name in sorted(filenames):
                path = os.path.join(dirpath, name)
                ext = os.path.splitext(name)[1].lower()
                if ext not in TEXT_EXT and ext not in PDF_EXT:
                    continue
                if any(x in path for x in excludes):
                    continue
                try:
                    st = os.stat(path)
                except OSError:
                    continue
                if st.st_size > data.MAX_FILE_BYTES:
                    continue
                yield path, st, ext

    def build(self, force=False):
        roots, problems = data.roots()
        excludes = data.exclusions()
        self.roots, self.problems = roots, list(problems)

        cached = _load_cache()
        fresh = (cached and not force
                 and cached.get("roots") == roots
                 and cached.get("demo") == data.is_demo())

        found = {}
        for root in roots:
            for path, st, ext in self._walk(root, excludes):
                found[path] = (st.st_mtime, st.st_size, ext)

        if fresh:
            old = cached["notes"]
            same = (set(old) == set(found)
                    and all(abs(old[p]["mtime"] - found[p][0]) < 1e-6 for p in found))
            if same:
                self._adopt(cached)
                return self

        notes = {}
        for path, (mtime, size, ext) in sorted(found.items()):
            text, unindexed = _read(path, ext)
            meta = _frontmatter(text) if text else {}
            body = text[len(FRONTMATTER.match(text).group(0)):] if FRONTMATTER.match(text or "") else text
            title = _title(text, path) if text else os.path.splitext(os.path.basename(path))[0]
            notes[path] = {
                "id": path,
                "title": title,
                "type": meta.get("type", _type_from_path(path)),
                "meta": meta,
                "text": body,
                "excerpt": _excerpt(body),
                "mtime": mtime,
                "size": size,
                "ext": ext,
                "links": [] if unindexed else sorted(set(WIKILINK.findall(body))),
                "unindexed": unindexed,
                "injection": scan_injection(body) if body else [],
                "tokens": {} if unindexed else _tf(body),
            }
        self._finalise(notes)
        _save_cache(self)
        return self

    def _finalise(self, notes):
        self.notes = notes
        self._by_title = {}
        for note in notes.values():
            self._by_title.setdefault(note["title"].lower(), note["id"])
            stem = os.path.splitext(os.path.basename(note["id"]))[0].lower()
            self._by_title.setdefault(stem, note["id"])
        edges = set()
        for note in notes.values():
            for link in note["links"]:
                dst = self._by_title.get(link.strip().lower())
                if dst and dst != note["id"]:
                    edges.add((note["id"], dst))
        self.edges = sorted(edges)
        self._adj = {i: set() for i in notes}
        for a, b in self.edges:
            self._adj[a].add(b)
            self._adj[b].add(a)
        self.built_at = time.time()

    def _adopt(self, cached):
        for note in cached["notes"].values():
            note.setdefault("tokens", {})
        self._finalise(cached["notes"])
        self.built_at = cached.get("built_at", time.time())

    # -- reading ----------------------------------------------------------
    def degree(self, nid):
        return len(self._adj.get(nid, ()))

    def hubs(self, n=10):
        return sorted(self.notes.values(), key=lambda x: (-self.degree(x["id"]), x["title"]))[:n]

    def counts_by_type(self):
        out = {}
        for note in self.notes.values():
            out[note["type"]] = out.get(note["type"], 0) + 1
        return dict(sorted(out.items()))

    def unindexed(self):
        return [n for n in self.notes.values() if n["unindexed"]]

    def search(self, query, limit=5):
        """tf-idf-ish scoring, plus a title-match bonus. Returns [(note, score)]."""
        qs = tokens(query)
        if not qs:
            return []
        n_docs = max(len(self.notes), 1)
        df = {}
        for term in set(qs):
            df[term] = sum(1 for note in self.notes.values() if term in note["tokens"]) or 1
        scored = []
        for note in self.notes.values():
            if note["unindexed"]:
                continue
            score = 0.0
            for term in qs:
                tf = note["tokens"].get(term, 0)
                if tf:
                    score += (1 + (tf ** 0.5)) * (n_docs / df[term]) ** 0.5
            title = note["title"].lower()
            for term in qs:
                if term in title:
                    score += 6.0
            if score:
                scored.append((note, score))
        scored.sort(key=lambda x: (-x[1], x[0]["title"]))
        return scored[:limit]

    def best_score(self, query):
        hits = self.search(query, limit=1)
        return hits[0][1] if hits else 0.0

    def path_between(self, a, b):
        """Shortest path, BFS. [] when unconnected."""
        if a not in self._adj or b not in self._adj:
            return []
        if a == b:
            return [a]
        prev, queue, seen = {a: None}, [a], {a}
        while queue:
            nxt = []
            for node in queue:
                for peer in sorted(self._adj[node]):
                    if peer in seen:
                        continue
                    seen.add(peer)
                    prev[peer] = node
                    if peer == b:
                        out, cur = [], b
                        while cur is not None:
                            out.append(cur)
                            cur = prev[cur]
                        return list(reversed(out))
                    nxt.append(peer)
            queue = nxt
        return []

    def graph_payload(self):
        ids = sorted(self.notes)
        idx = {nid: i for i, nid in enumerate(ids)}
        return {
            "nodes": [
                {
                    "i": idx[nid],
                    "id": nid,
                    "title": self.notes[nid]["title"],
                    "type": self.notes[nid]["type"],
                    "degree": self.degree(nid),
                    "unindexed": bool(self.notes[nid]["unindexed"]),
                }
                for nid in ids
            ],
            "edges": [[idx[a], idx[b]] for a, b in self.edges],
            "counts": self.counts_by_type(),
        }

    def stats(self):
        return {
            "ok": bool(self.notes),
            "notes": len(self.notes),
            "edges": len(self.edges),
            "types": self.counts_by_type(),
            "unindexed": len(self.unindexed()),
            "injection_flagged": sum(1 for n in self.notes.values() if n["injection"]),
            "roots": self.roots,
            "problems": self.problems,
            "built_at": self.built_at,
        }


def _type_from_path(path):
    parent = os.path.basename(os.path.dirname(path))
    return parent.rstrip("s") if parent else "note"


def _excerpt(text, n=280):
    body = re.sub(r"\s+", " ", re.sub(r"^#.*$", "", text or "", flags=re.M)).strip()
    return body[:n] + ("…" if len(body) > n else "")


def _tf(text):
    out = {}
    for word in tokens(text):
        out[word] = out.get(word, 0) + 1
    return out


# ---------------------------------------------------------------- cache
def _load_cache():
    try:
        with open(INDEX_PATH, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _save_cache(index):
    payload = {
        "version": 2,
        "demo": data.is_demo(),
        "roots": index.roots,
        "built_at": index.built_at,
        "notes": index.notes,
    }
    os.makedirs(data.DATA, exist_ok=True)
    tmp = INDEX_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(payload, fh)
    os.replace(tmp, INDEX_PATH)


# ---------------------------------------------------------------- singleton
_INDEX = None


def get(force=False):
    global _INDEX
    if _INDEX is None or force:
        _INDEX = Index().build(force=force)
    return _INDEX


def resolve_note_path(candidate):
    """Confine a requested note id to the indexed roots. Raises ValueError."""
    index = get()
    real = os.path.realpath(os.path.abspath(os.path.expanduser(candidate)))
    for root in index.roots:
        root_real = os.path.realpath(root)
        if real == root_real or real.startswith(root_real + os.sep):
            if real in index.notes:
                return real
            raise ValueError("not in index")
    raise ValueError("outside indexed roots")


if __name__ == "__main__":
    idx = get(force=True)
    s = idx.stats()
    print(f"roots: {s['roots'] or '(none)'}")
    for problem in s["problems"]:
        print(f"  problem: {problem}")
    print(f"notes: {s['notes']}   edges: {s['edges']}   unindexed: {s['unindexed']}")
    print("by type:")
    for k, v in s["types"].items():
        print(f"  {k:<10} {v}")
    print("top 10 hubs:")
    for note in idx.hubs(10):
        print(f"  {idx.degree(note['id']):>3}  {note['title']}")
    if s["injection_flagged"]:
        print(f"injection-flagged notes: {s['injection_flagged']} (reported, never obeyed)")
