"""THE ONLY FILE THAT TOUCHES REAL DATA.

Every other module asks this one for roots, inbox, calendar and tasks. `JARVIS_DEMO`
is read here and nowhere else. Default is demo — real life is opt-in.

Adapters that are not backed by a real source are named `Stub*` and say so in
`describe()`, which feeds /api/health and the on-screen banner. A stub never
pretends to be live.
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                      # jarvis/
DATA = os.path.join(ROOT, "data")
DEMO_VAULT = os.path.join(DATA, "demo_vault")

ALWAYS_EXCLUDE = ("node_modules", ".git", ".obsidian", ".venv", "__pycache__",
                  "site-packages", ".cache")
MAX_FILE_BYTES = 2 * 1024 * 1024


def _env(name, default=""):
    return os.environ.get(name, default).strip()


def is_demo():
    """The single read of JARVIS_DEMO in the whole codebase."""
    return _env("JARVIS_DEMO", "1") != "0"


# ------------------------------------------------------------------ vault roots
def roots():
    """Absolute folders to index, read-only. Returns (paths, problems)."""
    if is_demo():
        if not os.path.isdir(DEMO_VAULT):
            return [], ["demo vault missing — run python3 data/generate_demo.py"]
        return [DEMO_VAULT], []

    raw = _env("JARVIS_ROOTS")
    if not raw:
        return [], ["JARVIS_ROOTS is empty — question 12 of the interview is UNKNOWN"]
    paths, problems = [], []
    for part in raw.split(":"):
        part = os.path.abspath(os.path.expanduser(part.strip()))
        if not part:
            continue
        if os.path.isdir(part):
            paths.append(part)
        else:
            problems.append(f"not a directory: {part}")
    return paths, problems


def exclusions():
    extra = [p.strip() for p in _env("JARVIS_EXCLUDE").split(":") if p.strip()]
    return list(ALWAYS_EXCLUDE) + extra


# ------------------------------------------------------------------ adapters
class Adapter:
    name = "adapter"
    live = False
    detail = ""

    def describe(self):
        return {"name": self.name, "live": self.live, "detail": self.detail}


class StubInbox(Adapter):
    """Invented fixtures. Real mode needs IMAP or an API from interview Q10/Q11."""

    name = "inbox"
    live = False

    def __init__(self):
        self.detail = ("demo fixtures" if is_demo() else
                       "STUB — no mail source configured (interview Q10/Q11 UNKNOWN)")

    def messages(self):
        path = os.path.join(DATA, "demo_inbox.json")
        if not os.path.isfile(path):
            return []
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)


class StubCalendar(Adapter):
    name = "calendar"
    live = False

    def __init__(self):
        self.detail = ("demo fixtures" if is_demo() else
                       "STUB — no calendar configured (interview Q10/Q11 UNKNOWN)")

    def events(self):
        path = os.path.join(DATA, "demo_calendar.json")
        if not os.path.isfile(path):
            return []
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)


class StubTasks(Adapter):
    name = "tasks"
    live = False

    def __init__(self):
        self.detail = ("demo fixtures" if is_demo() else
                       "STUB — no task tracker configured (interview Q10/Q11 UNKNOWN)")

    def tasks(self):
        path = os.path.join(DATA, "demo_tasks.json")
        if not os.path.isfile(path):
            return []
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)


INBOX = StubInbox()
CALENDAR = StubCalendar()
TASKS = StubTasks()


def adapters():
    return [INBOX.describe(), CALENDAR.describe(), TASKS.describe()]


def summary():
    paths, problems = roots()
    return {
        "demo": is_demo(),
        "roots": paths,
        "problems": problems,
        "adapters": adapters(),
    }
