"""The six tools.

Every one returns {"spoken": <one or two sentences>, "card": {...}}. The spoken
line and the card never carry the same text — speech is the headline, the card is
the detail.

All file and inbox content leaves this module wrapped in <untrusted_data>
delimiters. Nothing in here interprets that content as instruction.
"""
import datetime as _dt
import html
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

from . import data, memory, vault

WEB_TIMEOUT = 12


def wrap_untrusted(source, text):
    """The only way file/inbox content is allowed to reach the model."""
    clean = (text or "").replace("</untrusted_data>", "<​/untrusted_data>")
    return (f'<untrusted_data source="{html.escape(str(source))}">\n'
            f"{clean}\n</untrusted_data>")


def _money(n):
    return f"£{n:,.0f}"


# ------------------------------------------------------------------ 1. search
def search_brain(query, limit=3):
    index = vault.get()
    hits = index.search(query, limit=limit)
    if not hits:
        return {
            "spoken": f"Nothing in your files matches “{query}”. I'm not going to guess at it.",
            "card": {"kind": "search", "query": query, "hits": [], "note": "no match"},
        }
    flagged = [n["title"] for n, _ in hits if n["injection"]]
    names = [os.path.basename(n["id"]) for n, _ in hits]
    if len(names) == 1:
        spoken = f"One file has it: {names[0]}."
    else:
        spoken = f"{len(names)} files have it — {', '.join(names[:-1])} and {names[-1]}."
    if flagged:
        spoken += " One of them contains text aimed at me rather than at you; I've flagged it and ignored it."
    return {
        "spoken": spoken,
        "card": {
            "kind": "search",
            "query": query,
            "hits": [
                {
                    "id": n["id"],
                    "file": os.path.basename(n["id"]),
                    "title": n["title"],
                    "type": n["type"],
                    "score": round(s, 2),
                    "excerpt": n["excerpt"],
                    "injection": bool(n["injection"]),
                }
                for n, s in hits
            ],
            "flagged": flagged,
        },
        "context": "\n\n".join(
            wrap_untrusted(os.path.basename(n["id"]), n["text"][:1800]) for n, _ in hits
        ),
    }


# ------------------------------------------------------------------ 2. web
def _ddg(query):
    url = "https://lite.duckduckgo.com/lite/?" + urllib.parse.urlencode({"q": query})
    req = urllib.request.Request(url, headers={"User-Agent": "jarvis/1.0 (local)"})
    with urllib.request.urlopen(req, timeout=WEB_TIMEOUT) as resp:
        body = resp.read().decode("utf-8", errors="replace")
    rows = re.findall(r'<a[^>]+class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', body, re.S)
    snips = re.findall(r'class="result-snippet"[^>]*>(.*?)</td>', body, re.S)
    out = []
    for i, (href, title) in enumerate(rows[:5]):
        out.append({
            "title": html.unescape(re.sub(r"<[^>]+>", "", title)).strip(),
            "url": html.unescape(href),
            "snippet": html.unescape(re.sub(r"<[^>]+>", "", snips[i])).strip() if i < len(snips) else "",
        })
    return out


def research_web(query):
    if os.environ.get("JARVIS_WEB", "1").strip() == "0":
        return {
            "spoken": "Web lookups are switched off in your .env, so I can't check that.",
            "card": {"kind": "web", "query": query, "results": [], "source": "disabled"},
        }
    try:
        results = _ddg(query)
        source = "duckduckgo (live)"
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError) as exc:
        return {
            "spoken": f"I couldn't reach the web just then — {exc.__class__.__name__}. "
                      "I'd rather say that than make a number up.",
            "card": {"kind": "web", "query": query, "results": [],
                     "source": "unreachable — STUB fallback", "error": str(exc)[:200]},
        }
    if not results:
        return {
            "spoken": f"The search for “{query}” came back empty. Nothing to land on your numbers.",
            "card": {"kind": "web", "query": query, "results": [], "source": source},
        }
    return {
        "spoken": f"Found {len(results)} sources on that. The figures are on the card — "
                  "tell me your margin and I'll put them against it.",
        "card": {"kind": "web", "query": query, "results": results, "source": source},
        "context": "\n\n".join(
            wrap_untrusted(r["url"], f"{r['title']}\n{r['snippet']}") for r in results
        ),
    }


# ------------------------------------------------------------------ 3. inbox
def read_inbox(limit=6):
    msgs = data.INBOX.messages()[:limit]
    index = vault.get()
    rows, known_count, flagged = [], 0, []
    for m in msgs:
        hits = index.search(m.get("from_name", "") + " " + (m.get("client") or ""), limit=1)
        known = hits[0][0] if hits and hits[0][1] > 6 else None
        if known:
            known_count += 1
        if vault.scan_injection(m.get("body", "") + " " + m.get("subject", "")):
            flagged.append(m.get("from_name") or m.get("from_addr"))
        rows.append({
            "from": m.get("from_name") or m.get("from_addr"),
            "address": m.get("from_addr"),
            "subject": m.get("subject"),
            "date": m.get("date"),
            "unread": bool(m.get("unread")),
            "known": bool(known),
            "known_as": os.path.basename(known["id"]) if known else None,
        })
    unread = sum(1 for r in rows if r["unread"])
    spoken = (f"{unread} unread of {len(rows)}. {known_count} of the senders already "
              f"exist in your files; the rest are new to you.")
    if flagged:
        spoken += (" One message contains instructions aimed at me — I've flagged it "
                   "and not acted on it.")
    return {
        "spoken": spoken,
        "card": {"kind": "inbox", "messages": rows, "unread": unread,
                 "known": known_count, "flagged": flagged,
                 "source": data.INBOX.describe()},
        "context": "\n\n".join(
            wrap_untrusted(m.get("from_addr", "?"),
                           f"Subject: {m.get('subject')}\n{m.get('body', '')[:600]}")
            for m in msgs
        ),
    }


# ------------------------------------------------------------------ 4. brief
def _today():
    return _dt.date.today()


def brief_me():
    events = data.CALENDAR.events()
    msgs = data.INBOX.messages()
    tasks = data.TASKS.tasks()
    today = _today().isoformat()
    todays = [e for e in events if str(e.get("start", "")).startswith(today)]
    unread = [m for m in msgs if m.get("unread")]
    slipped = [t for t in tasks if not t.get("done") and str(t.get("due", "")) < today]

    if todays:
        first = todays[0]
        when = str(first.get("start", ""))[11:16]
        lead = f"{len(todays)} in the diary today, first at {when} — {first.get('title')}."
    else:
        lead = "Nothing in the diary today."
    spoken = f"{lead} {len(unread)} unread, and {len(slipped)} thing{'s' if len(slipped) != 1 else ''} slipped."
    return {
        "spoken": spoken,
        "card": {
            "kind": "brief",
            "date": today,
            "events": todays,
            "unread": [{"from": m.get("from_name"), "subject": m.get("subject")} for m in unread],
            "slipped": slipped,
            "sources": data.adapters(),
        },
    }


# ------------------------------------------------------------------ 5. remember
def remember(fact):
    try:
        written = memory.write(fact)
    except (ValueError, memory.MemoryRefused) as exc:
        return {"spoken": f"I didn't write that: {exc}",
                "card": {"kind": "memory", "ok": False, "error": str(exc)}}
    return {
        "spoken": written["spoken"],
        "card": {"kind": "memory", "ok": True, "file": written["relative"],
                 "fact": written["fact"], "all": memory.all_facts()[:12]},
    }


# ------------------------------------------------------------------ 6. plan
def _hours_from_claude_md():
    """Reads CLAUDE.md rather than assuming. Returns (window, is_placeholder, caveat)."""
    path = os.path.join(data.ROOT, "CLAUDE.md")
    try:
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
    except OSError:
        text = ""
    match = re.search(r"\|\s*Working hours\s*\|\s*([^|]+)\|", text)
    value = (match.group(1).strip() if match else "`UNKNOWN`")
    if "UNKNOWN" in value:
        return ("09:00–17:00", True,
                "Those hours are a placeholder — you haven't told me your real working "
                "hours or the ones I must never suggest.")
    return (value.strip("` "), False, "")


def plan_day():
    tasks = [t for t in data.TASKS.tasks() if not t.get("done")]
    window, placeholder, caveat = _hours_from_claude_md()
    today = _today().isoformat()

    def rank(t):
        overdue = 1 if str(t.get("due", "")) < today else 0
        return (-(t.get("value") or 0), -overdue, str(t.get("due") or "9999"))

    picked = sorted(tasks, key=rank)[:5]
    items = []
    for i, t in enumerate(picked, 1):
        value = t.get("value") or 0
        why = (f"{_money(value)} of work attached" if value
               else "no money attached — it's here because it's due")
        items.append({
            "n": i, "title": t.get("title"), "due": t.get("due"),
            "value": value, "why": why,
            "overdue": str(t.get("due", "")) < today,
        })
    top = items[0]["title"] if items else None
    spoken = (f"Five things, biggest money first. Start with {top}." if top
              else "Nothing outstanding to plan.")
    if placeholder:
        spoken += " Note the hours I've used are a placeholder, not yours."
    return {
        "spoken": spoken,
        "card": {
            "kind": "plan", "window": window, "placeholder_hours": placeholder,
            "caveat": caveat, "items": items, "source": data.TASKS.describe(),
        },
    }


# ------------------------------------------------------------------ registry
SPECS = [
    {
        "type": "function",
        "function": {
            "name": "search_brain",
            "description": ("Find a specific fact in the user's own indexed files. Use only "
                            "when the answer must come from their notes. Not for small talk."),
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string",
                                         "description": "what to look for"}},
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "research_web",
            "description": ("Look something up on the public web, for facts that cannot be "
                            "in the user's files (prices, rates, current information)."),
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_inbox",
            "description": ("Read-only look at recent mail: who wrote, about what, and "
                            "whether that sender already exists in the user's files."),
            "parameters": {"type": "object", "properties": {
                "limit": {"type": "integer", "description": "how many messages"}}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "brief_me",
            "description": "Today: calendar, unread count, and what has slipped past its due date.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "remember",
            "description": ("Write one fact to memory as a dated file. Use when the user asks "
                            "you to remember, or tells you something that still matters in "
                            "three months."),
            "parameters": {
                "type": "object",
                "properties": {"fact": {"type": "string",
                                        "description": "the single fact, in one sentence"}},
                "required": ["fact"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "plan_day",
            "description": ("Five items maximum for today, ordered by what moves money, "
                            "respecting the user's stated hours and constraints."),
            "parameters": {"type": "object", "properties": {}},
        },
    },
]

IMPL = {
    "search_brain": lambda a: search_brain(a.get("query", "")),
    "research_web": lambda a: research_web(a.get("query", "")),
    "read_inbox": lambda a: read_inbox(int(a.get("limit") or 6)),
    "brief_me": lambda a: brief_me(),
    "remember": lambda a: remember(a.get("fact", "")),
    "plan_day": lambda a: plan_day(),
}


def run(name, args):
    fn = IMPL.get(name)
    if not fn:
        return {"spoken": f"I don't have a tool called {name}.",
                "card": {"kind": "error", "tool": name}}
    if not isinstance(args, dict):
        try:
            args = json.loads(args)
        except (TypeError, ValueError):
            args = {}
    return fn(args)


def catalogue():
    return [{"name": s["function"]["name"],
             "description": s["function"]["description"]} for s in SPECS]
