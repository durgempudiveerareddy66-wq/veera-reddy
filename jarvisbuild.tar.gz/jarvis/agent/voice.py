"""Local speech in and out, behind one interface.

No audio ever leaves this machine. STT is faster-whisper (base.en, CPU int8), TTS
is Piper with one small English voice. Both are optional: this module imports
cleanly with zero third-party packages present, and reports its own absence
through health() so the UI can show a banner instead of crashing.

Swapping engines is a one-line change: implement VoiceProvider and set PROVIDER.
"""
import io
import os
import shutil
import subprocess
import threading
import wave

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
VENV = os.path.join(ROOT, ".venv")
MODELS = os.path.join(ROOT, "data", "voice_models")
WHISPER_MODEL = os.environ.get("JARVIS_WHISPER_MODEL", "base.en")
SAMPLE_RATE = 16000


class VoiceProvider:
    """The whole interface. Implement these four and you have swapped the engine."""

    def stt_ready(self):
        raise NotImplementedError

    def tts_ready(self):
        raise NotImplementedError

    def transcribe(self, wav_bytes):
        raise NotImplementedError

    def speak(self, text):
        """Returns WAV bytes."""
        raise NotImplementedError


class LocalVoice(VoiceProvider):
    def __init__(self):
        self._stt = None
        self._stt_error = None
        self._stt_lock = threading.Lock()
        self._loading = False
        self._piper = _find_piper()
        self._voice = _find_voice()

    # ---------------------------------------------------------------- STT
    def stt_ready(self):
        try:
            import faster_whisper  # noqa: F401
        except Exception as exc:            # ImportError, or a broken install
            self._stt_error = f"{exc.__class__.__name__}: {exc}"
            return False
        return True

    def _load_stt(self):
        with self._stt_lock:
            if self._stt is not None:
                return self._stt
            self._loading = True
            try:
                from faster_whisper import WhisperModel
                self._stt = WhisperModel(
                    WHISPER_MODEL, device="cpu", compute_type="int8",
                    download_root=os.path.join(MODELS, "whisper"))
                self._stt_error = None
            except Exception as exc:
                self._stt_error = f"{exc.__class__.__name__}: {exc}"
                raise
            finally:
                self._loading = False
            return self._stt

    def weights_present(self):
        root = os.path.join(MODELS, "whisper")
        if not os.path.isdir(root):
            return False
        for dirpath, _dirs, files in os.walk(root):
            if any(f.endswith((".bin", ".onnx")) for f in files):
                return True
        return False

    def transcribe(self, wav_bytes):
        if not self.stt_ready():
            raise RuntimeError("speech-to-text unavailable: run ./setup_voice.sh")
        model = self._load_stt()
        tmp = os.path.join(MODELS, "_in.wav")
        os.makedirs(MODELS, exist_ok=True)
        with open(tmp, "wb") as fh:
            fh.write(wav_bytes)
        segments, info = model.transcribe(tmp, language="en", beam_size=1,
                                          vad_filter=True)
        text = " ".join(s.text.strip() for s in segments).strip()
        try:
            os.remove(tmp)
        except OSError:
            pass
        return {"text": text, "duration": round(getattr(info, "duration", 0.0), 2)}

    # ---------------------------------------------------------------- TTS
    def tts_ready(self):
        return bool(self._piper and self._voice)

    def speak(self, text):
        if not self.tts_ready():
            raise RuntimeError("text-to-speech unavailable: run ./setup_voice.sh")
        text = (text or "").strip()
        if not text:
            raise ValueError("nothing to speak")
        cmd = [self._piper, "--model", self._voice, "--output_file", "-"]
        proc = subprocess.run(cmd, input=text.encode(), stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=120)
        if proc.returncode != 0 or not proc.stdout:
            raise RuntimeError(f"piper failed: {proc.stderr.decode()[:200]}")
        return proc.stdout

    # ---------------------------------------------------------------- health
    def health(self):
        stt_ok = self.stt_ready()
        return {
            "stt": {
                "ok": stt_ok,
                "engine": "faster-whisper",
                "model": WHISPER_MODEL,
                "loaded": self._stt is not None,
                "loading": self._loading,
                "weights_present": self.weights_present(),
                "note": (None if stt_ok else
                         "voice offline: run ./setup_voice.sh"),
                "first_run": (stt_ok and not self.weights_present()),
                "first_run_note": ("first use downloads the base.en weights, "
                                   "about 75 MB — one time only"),
                "error": self._stt_error,
            },
            "tts": {
                "ok": self.tts_ready(),
                "engine": "piper",
                "binary": self._piper,
                "voice": os.path.basename(self._voice) if self._voice else None,
                "note": (None if self.tts_ready() else
                         "voice offline: run ./setup_voice.sh"),
            },
            "local_only": True,
            "note": "no audio leaves this machine",
        }


def _find_piper():
    for candidate in (os.path.join(VENV, "bin", "piper"),
                      shutil.which("piper")):
        if candidate and os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    # piper-tts installs as a python module in some builds
    if os.path.isfile(os.path.join(VENV, "bin", "python")):
        try:
            probe = subprocess.run(
                [os.path.join(VENV, "bin", "python"), "-c", "import piper"],
                capture_output=True, timeout=20)
            if probe.returncode == 0:
                return os.path.join(VENV, "bin", "piper")
        except (OSError, subprocess.SubprocessError):
            pass
    return None


def _find_voice():
    root = os.path.join(MODELS, "piper")
    if not os.path.isdir(root):
        return None
    for name in sorted(os.listdir(root)):
        if name.endswith(".onnx") and os.path.isfile(os.path.join(root, name + ".json")):
            return os.path.join(root, name)
    return None


# ------------------------------------------------------------------ WAV helpers
def pcm16_to_wav(pcm_bytes, rate=SAMPLE_RATE):
    """stdlib wave only — no external decoder anywhere in the audio path."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm_bytes)
    return buf.getvalue()


def wav_info(wav_bytes):
    with wave.open(io.BytesIO(wav_bytes), "rb") as wf:
        return {"channels": wf.getnchannels(), "rate": wf.getframerate(),
                "frames": wf.getnframes(),
                "seconds": round(wf.getnframes() / max(wf.getframerate(), 1), 2)}


PROVIDER = LocalVoice()


def health():
    return PROVIDER.health()
