#!/usr/bin/env python3
"""JARVIS server. Standard library only. Binds 127.0.0.1, never 0.0.0.0.

    python3 jarvis/agent/main.py

Works on a clean machine with no third-party packages: full text mode, keyword
routing when no model key is set, and a visible banner where voice would be.
"""
import json
import os
import sys
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    __package__ = "agent"

from . import data, llm, memory, tools, vault, voice  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
UI = os.path.join(ROOT, "ui")
ENV_PATH = os.path.join(ROOT, ".env")

HOST = "127.0.0.1"
MAX_BODY = 12 * 1024 * 1024          # a minute of 16 kHz mono WAV, with room
ALLOWED_ORIGIN_HOSTS = {"localhost", "127.0.0.1", "[::1]", "::1"}


# ------------------------------------------------------------------ helpers
def _origin_ok(headers):
    """DNS-rebinding guard. A missing Origin is fine (curl); a foreign one is not."""
    origin = headers.get("Origin")
    if origin:
        host = urllib.parse.urlparse(origin).hostname
        if host not in ALLOWED_ORIGIN_HOSTS:
            return False
    host_header = (headers.get("Host") or "").rsplit(":", 1)[0].strip("[]")
    if host_header and host_header not in {"localhost", "127.0.0.1", "::1"}:
        return False
    return True


class Handler(BaseHTTPRequestHandler):
    server_version = "jarvis"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        if os.environ.get("JARVIS_QUIET") != "1":
            sys.stderr.write("  %s %s\n" % (self.address_string(), fmt % args))

    # -- plumbing ---------------------------------------------------------
    def _send(self, code, body=b"", ctype="application/json", extra=None):
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj).encode(), "application/json")

    def _error(self, code, message):
        self._json({"error": message}, code)

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length > MAX_BODY:
            raise ValueError("body too large")
        return self.rfile.read(length) if length else b""

    def _guard(self):
        if not _origin_ok(self.headers):
            self._error(403, "rejected: request Origin/Host is not localhost")
            return False
        return True

    # -- routes -----------------------------------------------------------
    def do_GET(self):
        if not self._guard():
            return
        path = urllib.parse.urlparse(self.path).path
        query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)

        if path == "/api/health":
            return self._json(health_payload())
        if path == "/api/graph":
            return self._json(vault.get().graph_payload())
        if path == "/api/note":
            return self._note(query)
        if path == "/api/memory":
            return self._json({"facts": memory.all_facts()})
        if path == "/api/path":
            index = vault.get()
            a, b = (query.get("a") or [""])[0], (query.get("b") or [""])[0]
            try:
                a, b = vault.resolve_note_path(a), vault.resolve_note_path(b)
            except ValueError as exc:
                return self._error(400, str(exc))
            return self._json({"path": index.path_between(a, b)})
        return self._static(path)

    def do_HEAD(self):
        self.do_GET()

    def do_POST(self):
        if not self._guard():
            return
        path = urllib.parse.urlparse(self.path).path
        try:
            raw = self._body()
        except ValueError as exc:
            return self._error(413, str(exc))

        if path == "/api/ask":
            return self._ask(raw)
        if path == "/api/remember":
            return self._remember(raw)
        if path == "/api/listen":
            return self._listen(raw)
        if path == "/api/speak":
            return self._speak(raw)
        if path == "/api/reindex":
            vault.get(force=True)
            return self._json(vault.get().stats())
        return self._error(404, "no such endpoint")

    # -- handlers ---------------------------------------------------------
    def _static(self, path):
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        target = os.path.realpath(os.path.join(UI, rel))
        if not target.startswith(os.path.realpath(UI) + os.sep) or not os.path.isfile(target):
            return self._error(404, "not found")
        ctype = {
            ".html": "text/html; charset=utf-8",
            ".js": "text/javascript; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".svg": "image/svg+xml",
        }.get(os.path.splitext(target)[1], "application/octet-stream")
        with open(target, "rb") as fh:
            return self._send(200, fh.read(), ctype)

    def _note(self, query):
        nid = (query.get("id") or [""])[0]
        if not nid:
            return self._error(400, "id required")
        try:
            real = vault.resolve_note_path(nid)
        except ValueError as exc:
            return self._error(403, f"refused: {exc}")
        note = vault.get().notes[real]
        return self._json({
            "id": note["id"],
            "file": os.path.basename(note["id"]),
            "title": note["title"],
            "type": note["type"],
            "meta": note["meta"],
            "text": note["text"][:20000],
            "links": note["links"],
            "degree": vault.get().degree(real),
            "unindexed": note["unindexed"],
            "injection": note["injection"],
            "untrusted": True,
        })

    def _ask(self, raw):
        try:
            payload = json.loads(raw or b"{}")
        except ValueError:
            return self._error(400, "bad json")
        question = (payload.get("question") or "").strip()
        if payload.get("reset"):
            llm.SESSION.clear()
        answer = llm.ask(question)
        answer["health"] = health_payload()
        return self._json(answer)

    def _remember(self, raw):
        try:
            payload = json.loads(raw or b"{}")
        except ValueError:
            return self._error(400, "bad json")
        result = tools.remember(payload.get("fact") or payload.get("text") or "")
        return self._json(result)

    def _listen(self, raw):
        if not raw:
            return self._error(400, "no audio")
        health = voice.health()
        if not health["stt"]["ok"]:
            return self._json({"error": "stt unavailable",
                               "banner": "voice offline: run ./setup_voice.sh",
                               "health": health}, 503)
        # The browser sends raw 16 kHz mono PCM16 from the AudioWorklet; the WAV
        # container is built here with the stdlib wave module. No ffmpeg, no
        # external decoder anywhere in the audio path.
        if (self.headers.get("X-Audio-Format") or "").lower() == "pcm16":
            try:
                rate = int(self.headers.get("X-Audio-Rate") or voice.SAMPLE_RATE)
            except ValueError:
                rate = voice.SAMPLE_RATE
            raw = voice.pcm16_to_wav(raw, rate=rate)
        try:
            info = voice.wav_info(raw)
        except Exception:
            return self._error(400, "expected raw PCM16 (X-Audio-Format: pcm16) or a WAV")
        try:
            out = voice.PROVIDER.transcribe(raw)
        except Exception as exc:
            return self._json({"error": f"{exc.__class__.__name__}: {exc}"}, 500)
        out["audio"] = info
        return self._json(out)

    def _speak(self, raw):
        try:
            payload = json.loads(raw or b"{}")
        except ValueError:
            return self._error(400, "bad json")
        health = voice.health()
        if not health["tts"]["ok"]:
            return self._json({"error": "tts unavailable",
                               "banner": "voice offline: run ./setup_voice.sh",
                               "health": health}, 503)
        try:
            wav = voice.PROVIDER.speak(payload.get("text") or "")
        except Exception as exc:
            return self._json({"error": f"{exc.__class__.__name__}: {exc}"}, 500)
        return self._send(200, wav, "audio/wav")


# ------------------------------------------------------------------ health
def health_payload():
    index = vault.get()
    v = voice.health()
    client = llm.get()
    return {
        "model": client.health(),
        "index": index.stats(),
        "stt": v["stt"],
        "tts": v["tts"],
        "memory": memory.health(),
        "data": data.summary(),
        "audio": {"local_only": True, "note": "no audio leaves this machine"},
        "tools": tools.catalogue(),
        "guardrails": {
            "bind": HOST,
            "origin_locked": True,
            "writes_confined_to": memory.MEMORY_DIR,
            "vault_read_only": True,
            "untrusted_delimiters": True,
        },
    }


# ------------------------------------------------------------------ startup
def banner():
    h = health_payload()
    print("\n  JARVIS")
    print("  " + "-" * 52)
    mode = "DEMO — invented fixtures" if h["data"]["demo"] else "REAL — your folders"
    print(f"  data      {mode}")
    idx = h["index"]
    print(f"  index     {idx['notes']} notes, {idx['edges']} edges, "
          f"{idx['unindexed']} unindexed")
    for problem in idx["problems"]:
        print(f"            ! {problem}")
    m = h["model"]
    if m["configured"]:
        print(f"  model     {m['model']} via {m['provider']} — {m['mode']} mode")
    else:
        print("  model     OFFLINE — keyword routing (set XAI_API_KEY in .env)")
    print(f"  voice     stt {'ok' if h['stt']['ok'] else 'offline'} · "
          f"tts {'ok' if h['tts']['ok'] else 'offline'}"
          + ("" if h["stt"]["ok"] and h["tts"]["ok"] else "  → ./setup_voice.sh"))
    if idx["injection_flagged"]:
        print(f"  security  {idx['injection_flagged']} note(s) contain text aimed at the "
              "model — flagged, never obeyed")
    print("  " + "-" * 52)


def main():
    llm.load_env(ENV_PATH)
    if not os.path.isfile(ENV_PATH) and os.path.isfile(ENV_PATH + ".example"):
        print("  No .env yet — copy .env.example to .env when you have a key.")

    vault.get(force=True)

    client = llm.get()
    if client.key and not client.model and sys.stdin.isatty():
        llm.choose_model_interactively(ENV_PATH)
        llm.reset()

    banner()
    port = int(os.environ.get("JARVIS_PORT") or 8765)
    server = ThreadingHTTPServer((HOST, port), Handler)
    print(f"\n  http://{HOST}:{port}\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  stopped\n")
        server.server_close()


if __name__ == "__main__":
    main()
