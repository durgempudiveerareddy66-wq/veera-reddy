"""Writes to memory/ and nowhere else.

Every write is confined to MEMORY_DIR by realpath check, and every write returns
the exact text that was written so the caller can say it out loud. There is no
silent path.
"""
import datetime as _dt
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MEMORY_DIR = os.path.join(ROOT, "memory")

SAFE = re.compile(r"[^a-z0-9]+")


class MemoryRefused(PermissionError):
    """Raised when something tries to write outside memory/."""


def _confine(path):
    real = os.path.realpath(os.path.abspath(path))
    root = os.path.realpath(MEMORY_DIR)
    if real != root and not real.startswith(root + os.sep):
        raise MemoryRefused(f"refused: {real} is outside {root}")
    return real


def _slug(text, limit=48):
    out = SAFE.sub("-", text.lower()).strip("-")
    return (out[:limit].rstrip("-") or "note")


def write(fact, source="user"):
    """One fact, one dated file. Returns a dict the caller must read aloud."""
    fact = (fact or "").strip()
    if not fact:
        raise ValueError("nothing to remember")
    os.makedirs(MEMORY_DIR, exist_ok=True)
    now = _dt.datetime.now()
    stamp = now.strftime("%Y-%m-%d")
    base = f"{stamp}-{_slug(fact)}"
    path = _confine(os.path.join(MEMORY_DIR, base + ".md"))
    n = 2
    while os.path.exists(path):
        path = _confine(os.path.join(MEMORY_DIR, f"{base}-{n}.md"))
        n += 1

    body = (
        f"---\ndate: {now.isoformat(timespec='seconds')}\nsource: {source}\n"
        f"type: memory\n---\n\n# {fact}\n\nRecorded {now.strftime('%d %b %Y at %H:%M')}.\n"
    )
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(body)
    return {
        "path": path,
        "relative": os.path.relpath(path, ROOT),
        "fact": fact,
        "spoken": f"Written to {os.path.basename(path)}: “{fact}”.",
    }


def write_to(path, text):
    """Explicit-path write. Exists so the guardrail test can try to abuse it."""
    real = _confine(path)
    with open(real, "w", encoding="utf-8") as fh:
        fh.write(text)
    return real


def all_facts():
    if not os.path.isdir(MEMORY_DIR):
        return []
    out = []
    for name in sorted(os.listdir(MEMORY_DIR), reverse=True):
        if not name.endswith(".md"):
            continue
        path = os.path.join(MEMORY_DIR, name)
        try:
            with open(path, encoding="utf-8") as fh:
                text = fh.read()
        except OSError:
            continue
        title = next((l[2:].strip() for l in text.splitlines() if l.startswith("# ")), name)
        out.append({"file": name, "fact": title,
                    "date": name[:10] if name[:4].isdigit() else ""})
    return out


def health():
    return {"ok": True, "dir": MEMORY_DIR, "facts": len(all_facts())}
