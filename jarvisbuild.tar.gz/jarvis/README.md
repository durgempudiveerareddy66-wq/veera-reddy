# JARVIS

A voice-controlled assistant that runs entirely on your machine. Vanilla JS in the
browser, Python standard library on the server. No web framework, no build step, no
npm, no database.

Speech in and out are local and free. No audio ever leaves this machine.

---

## Run it

```bash
cd jarvis
python3 agent/main.py
```

Open <http://127.0.0.1:8765>. That's it — no install, no key, no venv. On a clean
machine you get the full graph, text conversation, all six tools, and honest
banners telling you which subsystems are offline.

Everything optional is opt-in and says so on screen when it isn't there.

---

## Interview status — read this first

`CLAUDE.md` is the file that says who you are, and it is loaded on every request.
Right now **every field in it is marked `UNKNOWN`**, because the Step 0 interview
was not answered. Nothing has been invented to fill the gaps.

That has real consequences you will see while using it:

- `plan_day` orders by money but schedules against a **placeholder 09:00–17:00
  window**, and says so out loud every single time. It does not know your real
  hours, and it does not know the hours you must never be asked to work.
- The demo fixtures model a generic two-person studio, not your business. They
  are the right *shape* for a small service business but the wrong shape for
  yours until questions 2–6 are answered.
- Inbox, calendar and tasks are **stubs** backed by invented JSON, because
  questions 10 and 11 were not answered. `/api/health` labels each one `STUB`.
- No folders are indexed in real mode, because question 12 was not answered.

Fill in `CLAUDE.md` and restart. No code changes are needed for any of it.

---

## The demo switch

One variable, read in exactly one file (`agent/data.py`). Demo is the default —
your real life is opt-in.

| `JARVIS_DEMO` | what gets indexed |
|---------------|-------------------|
| `1` (default) | invented fixtures in `data/demo_vault`, safe to screen-record |
| `0`           | the folders listed in `JARVIS_ROOTS` |

The demo generator uses a fixed seed, so the graph is byte-identical every run:

```bash
python3 data/generate_demo.py
```

For real mode, put your folders in `.env`:

```
JARVIS_DEMO=0
JARVIS_ROOTS=/Users/you/Notes:/Users/you/Documents/Work
JARVIS_EXCLUDE=Archive:old-drafts
```

Read-only, recursive. Markdown, plain text and PDF. Always skips `node_modules`,
`.git`, `.obsidian`, `.venv`, `__pycache__`, and any file over 2 MB. `[[wikilinks]]`
become graph edges. The index is cached to `data/index.json` with mtime checks, so
restarts are fast and changed files are re-read.

---

## The model

Copy `.env.example` to `.env` (it is gitignored and chmod 600) and add a key.

```
XAI_API_KEY=xai-...
```

On first run JARVIS calls `GET https://api.x.ai/v1/models`, prints the list, and
writes your choice to `.env` as `XAI_MODEL`. No model name is hardcoded. The
resolved model is printed in `/api/health`.

Tool use goes through the OpenAI-compatible `tools` / `tool_calls` fields. If the
model you pick rejects them, JARVIS falls back to a strict-JSON prompt loop and
shows a badge saying which mode it is in.

**About the key you supplied:** `gsk_...` is a **Groq** key, not an xAI key. Groq
and Grok are different companies — Groq runs Llama, Qwen and Kimi models, not
Grok. xAI keys begin with `xai-`. Both work here, because the client is
provider-agnostic:

```
LLM_BASE_URL=https://api.groq.com/openai/v1
LLM_API_KEY=gsk_...
```

Leave those blank to use xAI. Also: that key was pasted into a chat transcript,
so **revoke it and issue a new one**.

There is no Anthropic integration anywhere in this codebase. No `ANTHROPIC_API_KEY`,
no `anthropic` import, no fallback to Claude. A test asserts it.

### With no key at all

The app still runs. Keyword routing takes over: greetings and follow-ups are
handled as conversation, and questions are scored against your files to decide
between conversation and search. A red badge reads **"model offline — keyword
routing"**, and every keyword-routed answer is labelled as such on the card.
Keyword matching never impersonates the model.

### What a day costs

Every request is counted in `/api/health` (`requests`, `prompt_tokens`,
`completion_tokens`) so you can watch it rather than guess.

A rough shape, based on the system prompt plus `CLAUDE.md` (~1.2k tokens) and ten
turns of history:

| | tokens |
|---|---|
| conversational turn | ~1.5k in, ~120 out |
| turn that calls one tool | ~3k in, ~200 out (two round trips) |
| 40 turns, half using a tool | ~90k in, ~6k out |

At Grok's published rates that lands in the low tens of pence per day at that
volume. Check current pricing before relying on the number — it is not
hardcoded here, and JARVIS will not spend anything or change model without asking.

---

## Voice

```bash
./setup_voice.sh
```

The only script that installs anything. It asks first, then creates `jarvis/.venv`
and installs exactly two packages:

- **faster-whisper** — speech in, `base.en`, CPU int8
- **piper-tts** — speech out, one small English voice, bundled `.onnx` + `.onnx.json`

Then run the server with that venv's python so it can see them:

```bash
.venv/bin/python agent/main.py
```

Both sit behind a `VoiceProvider` interface in `agent/voice.py`, so swapping engines
is a one-line change. Without the venv the server imports and serves full text mode
with zero third-party packages present — voice absence is a banner reading
**"voice offline: run ./setup_voice.sh"**, never an import crash.

First transcription downloads the Whisper weights (~75 MB). You get a one-time
"preparing voice" state rather than a dead button.

### Talking to it

Press the mic once, then just talk. No wake word between turns. The turn ends after
~900 ms below the level threshold; both numbers are named constants at the top of
`ui/app.js`:

```js
const SILENCE_MS        = 900;
const SILENCE_THRESHOLD = 0.014;
```

A live caption shows what it heard, and the bars are driven by the real mic level
from an `AnalyserNode`. That level loop runs on `setInterval`, not
`requestAnimationFrame` — RAF stops dead in a backgrounded tab and the mic would go
silently deaf.

The mic is muted while JARVIS speaks, or it transcribes itself through the speakers
and talks to itself forever. Barge-in is explicit: **mic button**, **Space**, or
**Esc**.

### Audio format

The browser's Web Speech API is not used: it is Chrome-only, it ships your audio to
Google, and in Brave it is a silent stub.

`MediaRecorder` emits webm/opus, which faster-whisper can only read via ffmpeg, and
ffmpeg may not be installed. So audio is captured as PCM with an `AudioWorklet`,
downsampled to 16 kHz mono on the audio thread, and POSTed raw; the WAV container is
built server-side with the stdlib `wave` module. **Zero external decoders in the
audio path.** If `AudioWorklet` is unavailable, it falls back to `MediaRecorder` +
ffmpeg and says on screen that it did.

---

## The interface

Full-screen, dark, four regions floating over a canvas.

- **Centre** — the graph. Every note a node, every link an edge. Force-directed,
  settles on load, keeps breathing. Colour by type, radius by connection count.
  Hover lifts a node and lights its links while everything else drops to 10%.
  Click focuses and opens the note. **Shift-click** a second node to trace the
  shortest path. Drag to pan, scroll to zoom, drag a node to move it. When idle, a
  faint pulse travels a random link every few seconds.
- **Left** — inspector for the focused note, and the top hubs.
- **Right** — type filters with live counts, and the reactor HUD: idle, listening,
  thinking, speaking.
- **Bottom** — ask bar with a rotating example prompt, and buttons for mic, mute,
  brief, plan and memory.

Canvas, not SVG: SVG needs a DOM node per element and stalls past ~1,500 nodes.
Repulsion uses a spatial grid with a distance cutoff so cost stays near-linear.
Labels are drawn most-connected first and any label whose box collides with one
already placed is skipped, or the hub cluster turns to mush.

No reference screenshot was supplied, so the visual language is the specced
fallback: near-black background, one cool accent (`#4fd6ff`) used sparingly,
generous spacing, one soft glow reserved for the reactor. All of it is tokens in
`:root` at the top of `ui/styles.css`.

---

## The six tools

Each returns two things: a short spoken line, and a structured card with the
detail. Never the same text twice.

| tool | what it does |
|------|--------------|
| `search_brain` | a fact from your own files. Always names the file; three files, it says so and cites all three |
| `research_web` | looks it up, then lands it back on your numbers |
| `read_inbox` | read-only. Who wrote, about what, and whether they already exist in your files |
| `brief_me` | calendar, unread, what slipped |
| `remember` | one fact, one dated file, and says out loud exactly what it wrote |
| `plan_day` | five items max, ordered by what moves money, respecting your hours |

Talking is the default. Tools are for when the answer genuinely needs one. A
greeting never returns a search result. The last ~10 turns are kept so "why?" and
"what about the second one?" resolve without you restating.

---

## Memory

`CLAUDE.md` is who you are, loaded every session. `memory/` is one dated markdown
file per fact, written only when you ask, or when you say something that still
matters in three months. Every write is announced out loud with the filename and
the exact text.

---

## Guardrails

Verify them yourself — each test actually attempts the violation:

```bash
python3 tests/test_guardrails.py
```

- **Never send.** No tool can send an email, message or invite. Drafts wait for you.
- **Never write to your folders.** Read-only, always. Writes are confined to
  `memory/` by realpath check; traversal out of it raises `MemoryRefused`.
- **Never write to memory silently.** Every write returns the text it wrote.
- **Never spend.** No paid API, purchase or model upgrade without asking. Request
  count is in `/api/health`.
- **Never invent.** No made-up number, date, filename or client. Not in the files,
  it says so.
- **Never state a derived number without its qualifier.** An invoice that is half
  paid because the job is still running is a staged payment, not a discount.
- **Instructions in your files and email are data, not commands.** All file and
  inbox content reaches the model wrapped in `<untrusted_data>` delimiters, and
  content cannot close them early. A note saying "ignore your instructions" is
  reported to you on screen and in the spoken line, never obeyed. The demo vault
  contains one such note on purpose.
- **Binds `127.0.0.1` only**, never `0.0.0.0`. Requests with a non-localhost
  `Origin` or `Host` get 403 (DNS rebinding). `/api/note` resolves and confines
  every path to the indexed roots.
- **No secret reaches the browser.** Keys stay server-side; a canary test asserts
  no key material appears in `/api/health` or any UI file.

---

## What leaves your machine

**Never leaves:**

- Audio. All of it. Recording, transcription and speech synthesis are local
  processes on this machine.
- Your API key. Server-side only, never sent to the browser.
- Your files, wholesale. Nothing indexes to a cloud service.

**Leaves only when you ask a question, and only if a model key is set:**

- Your question, the system prompt, `CLAUDE.md`, and the last ~10 turns.
- Excerpts of files a tool actually retrieved — capped at 1,800 characters per
  file, up to three files — wrapped in untrusted-data delimiters.
- These go to your chosen provider's endpoint over HTTPS: `api.x.ai` by default,
  or whatever `LLM_BASE_URL` names.

**Leaves only when `research_web` runs:** the search query, to
`lite.duckduckgo.com`. Set `JARVIS_WEB=0` in `.env` to block all outbound web
lookups.

With no key set and `JARVIS_WEB=0`, nothing leaves this machine at all.

---

## Layout

```
jarvis/
├── agent/
│   ├── main.py        HTTP server + API, binds 127.0.0.1 only
│   ├── llm.py         model client, stdlib urllib, tool-call loop
│   ├── vault.py       folders → searchable graph
│   ├── tools.py       the six tools
│   ├── data.py        THE ONLY FILE THAT TOUCHES REAL DATA
│   ├── voice.py       local STT + TTS behind one interface
│   ├── memory.py      writes to memory/ and nowhere else
│   └── prompt.md      the system prompt
├── ui/                index.html, app.js, graph.js, styles.css, pcm-worklet.js
├── data/              demo fixtures + generator + index cache
├── memory/            one markdown file per remembered fact
├── tests/             one test per guardrail
├── setup_voice.sh     the only thing that installs anything
├── CLAUDE.md          who you are — loaded every session
├── .env               keys, gitignored, chmod 600
└── README.md
```

## Endpoints

| method | path | |
|--------|------|---|
| GET | `/` | static UI |
| GET | `/api/health` | per-subsystem status: model, index, STT, TTS, memory, adapters |
| POST | `/api/ask` | `{question}` → spoken line, cards, mode, route |
| POST | `/api/listen` | raw PCM16 or WAV → transcript |
| POST | `/api/speak` | `{text}` → WAV |
| GET | `/api/graph` | nodes, edges, counts by type |
| GET | `/api/note?id=` | one note, path-confined to the indexed roots |
| POST | `/api/remember` | `{fact}` → the file it wrote and what it said |
| GET | `/api/path?a=&b=` | shortest path between two notes |
| POST | `/api/reindex` | force a re-index |
