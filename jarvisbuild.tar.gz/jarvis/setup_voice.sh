#!/usr/bin/env bash
# The only script in this project that installs anything.
#
# Everything lands in jarvis/.venv and jarvis/data/voice_models. Nothing here runs
# automatically — you run it deliberately. The server works fine without it; voice
# is simply reported as offline until this has been run.
#
# Installs exactly two things and their dependencies:
#   faster-whisper   speech in   (base.en, CPU int8)
#   piper-tts        speech out  (one small English voice)
#
# No audio ever leaves your machine. These run locally.

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="$HERE/.venv"
MODELS="$HERE/data/voice_models"
VOICE_DIR="$MODELS/piper"

VOICE_NAME="${JARVIS_PIPER_VOICE:-en_GB-alba-medium}"
VOICE_BASE="https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_GB/alba/medium"

echo
echo "  JARVIS voice setup"
echo "  ----------------------------------------------------"
echo "  This will install into:"
echo "    $VENV"
echo "    $MODELS"
echo
echo "  Packages: faster-whisper, piper-tts (plus their dependencies)."
echo "  Download: roughly 400 MB of wheels, ~75 MB of Whisper weights on"
echo "  first transcription, and ~65 MB for the Piper voice."
echo
read -r -p "  Go ahead? [y/N] " reply
case "$reply" in
  [yY]|[yY][eE][sS]) ;;
  *) echo "  Cancelled. Nothing installed."; exit 0 ;;
esac

command -v python3 >/dev/null || { echo "  python3 not found."; exit 1; }

echo
echo "  → creating venv"
python3 -m venv "$VENV"
"$VENV/bin/python" -m pip install --quiet --upgrade pip

echo "  → installing faster-whisper"
"$VENV/bin/pip" install --quiet faster-whisper

echo "  → installing piper-tts"
if ! "$VENV/bin/pip" install --quiet piper-tts; then
  echo "  ! piper-tts did not install from PyPI on this platform."
  echo "    Speech-to-text will still work. For speech out, drop a Piper binary"
  echo "    on your PATH and a voice into $VOICE_DIR."
fi

echo "  → fetching Piper voice: $VOICE_NAME"
mkdir -p "$VOICE_DIR"
fetch() {
  if command -v curl >/dev/null; then curl -fsSL "$1" -o "$2"
  else wget -q "$1" -O "$2"; fi
}
if [ ! -f "$VOICE_DIR/$VOICE_NAME.onnx" ]; then
  fetch "$VOICE_BASE/$VOICE_NAME.onnx"      "$VOICE_DIR/$VOICE_NAME.onnx" || true
  fetch "$VOICE_BASE/$VOICE_NAME.onnx.json" "$VOICE_DIR/$VOICE_NAME.onnx.json" || true
fi
if [ ! -s "$VOICE_DIR/$VOICE_NAME.onnx" ]; then
  rm -f "$VOICE_DIR/$VOICE_NAME.onnx" "$VOICE_DIR/$VOICE_NAME.onnx.json"
  echo "  ! Voice download failed. Put a .onnx and matching .onnx.json into:"
  echo "    $VOICE_DIR"
fi

cat <<EOF

  ----------------------------------------------------
  Done.

  Run the server with the venv's python so it can see these:

    $VENV/bin/python agent/main.py

  Plain 'python3 agent/main.py' still works — voice will just report
  offline. Check /api/health to see which subsystems came up.

  No audio leaves this machine.

EOF
