# veera-reddy

## JARVIS

A local voice-controlled assistant — vanilla JS in the browser, Python standard
library on the server. No web framework, no build step, no npm, no database.

```bash
cd jarvis
python3 agent/main.py
```

Then open <http://127.0.0.1:8765>. Full setup, the `JARVIS_DEMO` switch, voice
install, where the API key goes, and exactly what does and does not leave your
machine are all in **[jarvis/README.md](jarvis/README.md)**.

`jarvis/CLAUDE.md` currently has every personal field marked `UNKNOWN` — the
setup interview has not been answered yet, and nothing was invented to fill it in.
